


<!-- CHECK IF AUTHORIZED-->
<?php //if(session()->has('deptheadsession')){ }else{ echo '<meta http-equiv="refresh" content="0;url=https://recruitment.amaes.com/Err">';}?>


        <div class="buttonswrapper">

                    <a href="/Dept/Head/Resigned">
                    <button type="button" class="side-menu-btn">
                      <i class="fa fa-bell" aria-hidden="true"></i> &nbsp; Dashboard
                    </button></a>

                    <a href="/Dept/Head/MRF">
                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-file-text" aria-hidden="true"></i> &nbsp; MRF Requests
                    </button></a>
                    
                    <a href="/Dept/Head/applications">
                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-users" aria-hidden="true"></i> &nbsp; Applications
                    </button></a>

                    <br><br><br><br><br>

                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-user" aria-hidden="true"></i> &nbsp; Account
                    </button>
                    
                  </div><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/depthead/leftmenu.blade.php ENDPATH**/ ?>