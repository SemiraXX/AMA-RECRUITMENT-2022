
<div class="hr-dashboard-main-content-wrapper">

  <!--MAIN HEADER MENU TAB-->
  <?php echo $__env->make('hr.applicants.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



  <!-- LIST OF ALL APPLICATIONS -->
  <?php  $allapplications = DB::table('tbl_applications')->where('status', 'Awaiting')->orderBy('date_applied', 'DESC')->get(); ?>

  <?php $__currentLoopData = $allapplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <div class="hrwrapperforapplicationslist">
  <div class="row">
      <div class="col-sm-1">
      <p><i class="fa fa-file" aria-hidden="true"></i></p>
      </div>
      <div class="col-sm-5">
      <p class="position-title"><?php echo e($applicants->lname); ?>, <?php echo e($applicants->fname); ?></p>
      <p class="appplication-label1"><?php echo e($applicants->position_applying); ?></p>
      </div>
      <div class="col-sm-3">
        <?php echo $__env->make('hr.applicants.ratings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
      </div>
      <div class="col-sm-3">
        <div class="input-group">
            <button type="button" class="manageapplicants-btn manage_data" id="<?php echo e($applicants->id); ?>" onclick="this.style.backgroundColor='#ACACAC'">Manage</button>
            <button type="button" class="manageapplicants-btn get_data" id="<?php echo e($applicants->id); ?>" onclick="this.style.backgroundColor='#ACACAC'">View</button>
        </div>
    </div>
  </div>
  </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  

</div>





<!-- The Modal -->
<div class="modal fade" id="applicantdetails">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <!-- Modal body -->
      <div class="modal-body">

        <div class="input-group tab-wrapper">
            <a href="#"><button id="btntabprofile" type="button" onclick="tabprofile()" class="hr-applicant-info-tab-btn info-tab-btn-active">Profile</button></a>
            <a href="#"><button id="btntabprofile" type="button" onclick="tabeduc()" class="hr-applicant-info-tab-btn">Education</button></a>
            <a href="#"><button id="btnother" type="button" onclick="tabother()" class="hr-applicant-info-tab-btn">Other info</button></a>
            <a href="#"><button id="btnjob" type="button" onclick="tabattachements()" class="hr-applicant-info-tab-btn">Attachments</button></a>
        </div>
        <div class="container"  style="background-color:white">
        <br>
        <div id="applicant_details"></div>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        <br> <br>
        </div>
      </div>

    </div>
  </div>
</div>



<!-- The Modal -->
<div class="modal fade" id="manageapplication">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">
    <form action="<?php echo e(route('update.status')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

      <!-- Modal body -->
      <div class="modal-body">

        <div class="input-group tab-wrapper">
            <a href="#"><button id="btntabprofile" type="button" onclick="Manage()" class="hr-applicant-info-tab-btn info-tab-btn-active">Manage</button></a>
        </div>
        <div class="container"  style="background-color:white">

        <br>
            <div class="row">
                <div class="col-sm-6">
                <div id="applicant_manage_details"></div>
                </div>
                <div class="col-sm-6"> 
                <br>
                    <h1 class="modify-status-label">Modify Status</h1>
                    <select name="application_status" class="appform-input" required>
                    <option value="For-Interview">For-Interview</option>
                    <option value="For-Exam">For-Exam</option>
                    <option value="For-Evaluation">For-Evaluation</option>
                    <option value="For-Compliance">For-Compliance</option>
                    <option value="For-Onboarding">For-Onboarding</option>
                    </select>
                    <br>
                    <p class="info-label-1">Exam Code</p>
                    <select name="examcode" class="appform-input">
                    <option value="Not-set">Not-set</option>
                    <?php $exams = DB::table('ExamMaster')->orderBy('SetCode', 'ASC')->get(); ?>
                    <?php $__currentLoopData = $exams; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $exam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($exam->SetCode); ?>"><?php echo e($exam->SetCode); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                    <p class="info-label-1">Interviewer</p>
                    <select name="interviewer" class="appform-input">
                    <option value="Not-set">Not-set</option>
                    <option value="interviewer1">interviewer1</option>
                    <option value="interviewer2">interviewer2</option>
                    </select>
                    <br>
                    <p class="info-label-1">Message</p>
                    <textarea class="appform-input" style="height: auto;" rows="5" name="message"></textarea>

                
                    <button type="submit" class="manageapplicants-btn">Proceed</button>
                </div>
            </div>
            
    </form>
        <br> <br>
        </div>
      </div>

    </div>
  </div>
</div>


<!-- The Modal 
<div class="modal fade" id="manageapplication">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      
      <div class="modal-body">

        <div class="input-group tab-wrapper">
            <a href="#"><button id="btntabprofile" type="button" onclick="Manage()" class="hr-applicant-info-tab-btn info-tab-btn-active">Manage Applicantion</button></a>
            <a href="#"><button id="btnother" type="button" onclick="tabother()" class="hr-applicant-info-tab-btn">Requirements</button></a>
            <a href="#"><button id="btnjob" type="button" onclick="tabattachements()" class="hr-applicant-info-tab-btn">Exam Results</button></a>
            <a href="#"><button id="btnjob" type="button" onclick="tabattachements()" class="hr-applicant-info-tab-btn">Evaluation</button></a>
        </div>
        <div class="container"  style="background-color:white">
        <br>
        <div id="applicant_manage_details"></div>
        <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
        <br> <br>
        </div>
      </div>

    </div>
  </div>
</div><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/hr/applicants/all.blade.php ENDPATH**/ ?>