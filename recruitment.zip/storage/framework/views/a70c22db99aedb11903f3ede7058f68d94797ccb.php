<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <link href="/css/application.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

  <?php echo $__env->make('applicant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="applicationswrapper">

        <div class="list-applicationswrapper2">

            <p class="appform-title1">Applications</p>

            <div class="input-group tab-wrapper">
                <a href="#"><button id="btnjob" type="button" class="application-tab-btn active-tab">My Jobs</button></a>
                <a href="#"><button id="btnjob" type="button" class="application-tab-btn">Saved Jobs</button></a>
                <a href="#"><button id="btnjob" type="button" class="application-tab-btn">Recently Viewed</button></a>
            </div>
            
            <div class="tab-content-view">        

                <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="row submittedapplicationswrapper">
                    <div class="col-sm-1">
                    <img src="/assets/ama-br-logo.png" class="application-logo">
                    </div>
                    <div class="col-sm-9">
                        <p class="position-title"><?php echo e($application->position_applying); ?></p>
                        <p class="appplication-label1"><span class="status-label"><?php echo e($application->status); ?></span>
                        <i class="fa fa-map-marker" aria-hidden="true"></i>AMACC - Makati &nbsp;|&nbsp;
                        <i class="fa fa-clock-o" aria-hidden="true"></i> <?php echo e($application->date_applied); ?></p>
                    </div>
                    <div class="col-sm-2">
                    <form action="<?php echo e(route('application.view')); ?>" method="get">
                        <button type="submit" class="updateapplicationbtn">Manage</button>
                        <input type="hidden"  name="id"  value="<?php echo e($application->id); ?>"> 
                    </form>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                

                            
            </div>

        </div>
  </div>

  <?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="/script/application.js"></script>
</body>
</html><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/applicant/applications/applications.blade.php ENDPATH**/ ?>