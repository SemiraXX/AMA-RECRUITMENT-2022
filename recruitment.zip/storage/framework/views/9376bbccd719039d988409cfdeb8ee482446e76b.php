
<div class="hr-dashboard-main-content-wrapper">

     
<div class="form-wrapper-for-e201">

    <p class="tab-title-text">Personal Info</P>
    <br><br>
    <div class="row">
        <div class="col-sm-3">
            <p class="e201-form-label">Employee ID:</p>
            <input type="text" name="name" class="e201-input" value="0001"  required> 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Last Name:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->fname); ?>"  required> 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Fist Name:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->lname); ?>"  required> 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Middle Name:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-3">
            <p class="e201-form-label">Suffix:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Nickname:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Gender:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Birthdate:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-12">
            <p class="e201-form-label">Birth Place:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-4">
            <p class="e201-form-label">Civil Status:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Citizenship:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Religion:</p>
            <input type="text" name="name" class="e201-input" value="<?php echo e($applicants->mname); ?>"  required> 
        </div>
    </div>

    <br><br>
</div>


</div>






<?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/hr/applicants/transferform.blade.php ENDPATH**/ ?>