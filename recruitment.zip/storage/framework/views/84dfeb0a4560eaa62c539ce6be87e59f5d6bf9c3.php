<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/profile.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <link href="/css/mobile.css" rel="stylesheet">
  <link href="/css/mobileprofile.css" rel="stylesheet">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <!--for pdf
  <link href="css/smoothness/jquery-ui-1.9.0.custom.css" rel="stylesheet">
  <script language="javascript" type="text/javascript" src="jquery-1.8.2.js"></script>
  <script src="js/jquery-ui-1.9.0.custom.js"></script>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/css/bootstrap.min.css">
  <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.1/dist/umd/popper.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"></script>-->
  <!--for pdf-->
</head>
<body style="background-color:#EFEFEF;  overflow-x: hidden !important;">

  
  <?php echo $__env->make('applicant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="profilemainwrapper">
    

        <div class="profile-content-wrapper">
          <div class="row">

            <div class="col-sm-1">
              <div class="profile-pic-wrapper">
              <p class="profile-pic"><i class="fa fa-user" aria-hidden="true"></i></p>
              </div>
            </div>
            <div class="col-sm-5">
              <div class="profile-top-content-wrapper">
              <p class="profile-top-name"><?php echo e($applicants->fname); ?> <?php echo e($applicants->lname); ?></p>
              <p class="profile-top-sub-names"><?php echo e($applicants->complete_address); ?> | <?php echo e($applicants->city); ?></p>
              <?php if($applicants->isverified == 0): ?>
              <p class="profile-verify-info">NOT VERIFIED</p>
              <?php else: ?>
              <p class="profile-verify-info">ACCOUNT VERIFIED</p>
              <?php endif; ?>
              <p class="profile-top-sub-names">Last Login: <?php echo e($applicants->last_login); ?></p>
              </div>
            </div>
            <div class="col-sm-6">
              <div class="profile-top-content-wrapper">
                <p class="profile-contact-info"> 
                <?php echo e($applicants->email); ?> <i class="fa fa-envelope" aria-hidden="true"></i> 
                </p>
                <p class="profile-contact-info"> 
                <?php echo e($applicants->contact_number); ?> <i class="fa fa-phone-square" aria-hidden="true"></i>
                </p> 
                <a href="/applicant/edit/profile">
                  <button type="button" class="edit-profile-btn" >Edit Profile</button>
                </a>
              </div>
            </div>

          </div>
        </div>


        
        <div class="row">
          

          <!-- PERSONAL DETAILS-->
          <div class="col-sm-4">

              <div class="profile-sub-details-wrapper">
    

              <p class="profile-top-name">Personal Information <a href="/applicant/edit/profile"class="editlink">Edit</a><p>
              <p class="profile-top-sub-names">Gender: <?php echo e($applicants->gender); ?></p>
              <p class="profile-top-sub-names">Birthdate: <?php echo e($applicants->birthdate); ?></p>
              <p class="profile-top-sub-names">Birth Place: <?php echo e($applicants->birthplace); ?></p>
              <p class="profile-top-sub-names">Civil Status: <?php echo e($applicants->civilstatus); ?></p>
              <p class="profile-top-sub-names">Citizenship: <?php echo e($applicants->citizenship); ?></p>
              <p class="profile-top-sub-names">Religion: <?php echo e($applicants->religion); ?></p>
              <p class="profile-top-sub-names">Mother: <?php echo e($applicants->mother_name); ?></p>
              <p class="profile-top-sub-names">Father: <?php echo e($applicants->father_name); ?></p>
              <p class="profile-top-sub-names">No. of siblings: <?php echo e($applicants->no_of_siblings); ?></p>
              <p class="profile-top-sub-names">Spouse: <?php echo e($applicants->spouse); ?></p>
              <p class="profile-top-sub-names">Drivers License: <?php echo e($applicants->drivers_license); ?></p>
              <p class="profile-top-sub-names">Restriction: <?php echo e($applicants->restriction); ?></p>
              <br>
              <p class="profile-top-name">Other Details<p>
              <p class="profile-top-sub-names">SSS: <?php echo e($applicants->sss); ?></p>
              <p class="profile-top-sub-names">TIN: <?php echo e($applicants->tin); ?></p>
              <p class="profile-top-sub-names">PhilHealth: <?php echo e($applicants->philhealth); ?></p>
              <p class="profile-top-sub-names">Pag-ibig fund: <?php echo e($applicants->pagibig); ?></p>
              <p class="profile-top-sub-names">Last Login: <?php echo e($applicants->last_login); ?></p>
              <br>
              <p class="profile-top-name">My Resume<p>
                <div class="resume-border-wrapper">
                    <?php if($resume): ?>
                      <a href="#" onclick="resumeview()">
                      <div class="input-group resume-border">
                      <h1 class="my-resume-icon"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></h1>
                      <p class="my-resume-text"><?php echo e($resume->file); ?></p>
                      </div>
                      </a>
                    <?php else: ?>
                      <a href="#" data-target="#resume" data-toggle="modal">
                        <p class="my-resume-text">Upload</p>
                      </a>
                    <?php endif; ?>
                </div>
                <br>
              </div>
          </div>


           <!-- OTHER DETAILS-->
           <div class="col-sm-8">
            

              <div class="profile-sub-details-wrapper-2">
              <!--EDUCATION -->
              <p class="profile-top-name">Educational Attainment <a href="/applicant/edit/profile#education"class="editlink">Edit</a><p>

              
              <?php if(!$educations->isEmpty()): ?>
                  

                  <div class="row">
                    <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-6">
                      <div class="profile-cred-container">
                          <p class="profile-cred-details-title"><?php echo e($education->educational_level); ?></p>
                          <p class="profile-cred-details"><strong><?php echo e($education->date_attended); ?></strong></p>
                          <p class="profile-top-sub-names"><?php echo e($education->address); ?></p>
                          <p class="profile-top-sub-names"><?php echo e($education->name_of_institution); ?></p>
                          <p class="profile-top-sub-names"><?php echo e($education->degree); ?></p>
                      </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>


                  
                 
              <?php else: ?>

              <h2 class="no_data_found">No data found</h2>
    
              <?php endif; ?>
             
                


                <br>


                <!--FAMILY -->
                <p class="profile-top-name">Family Background <a href="/applicant/edit/profile#family"class="editlink">Edit</a><p>
                <div class="table-wrapper">
                <?php if(!$families->isEmpty()): ?>
                  <table class="table table-bordered">
                 
                      <tr>
                        <th>Name</th>
                        <th>Relationship</th>
                        <th>Family Birthday</th>
                        <th>Occupation</th>
                        <th>Address</th>
                        <th>Contact</th>
                      </tr>
                   
                   
                        <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <td><?php echo e($family->name); ?></td>
                          <td><?php echo e($family->relationship); ?></td>
                          <td><?php echo e($family->birthday); ?></td>
                          <td><?php echo e($family->occupation); ?></td>
                          <td><?php echo e($family->address); ?></td>
                          <td><?php echo e($family->contact_number); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    
                  </table>
                <?php else: ?>
                <h2 class="no_data_found">No data found</h2>
                <?php endif; ?>
              </div>


                <br>


                <!--FAMILY -->
                <p class="profile-top-name">Employment History<p>
                <div class="table-wrapper">
                <?php if(!$employment->isEmpty()): ?>
                <table class="table table-bordered">
                      <tr>
                        <th>Employer</th>
                        <th>Job Title</th>
                        <th>Address</th>
                        <th>Date Employed</th>
                        <th>Contact</th>
                        <th>Start Rate</th>
                        <th>End Rate</th>
                        <th>Separation Reason</th>
                      </tr>
                      <?php $__currentLoopData = $employment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employ): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                        <td><?php echo e($employ->employer); ?></td>
                        <td><?php echo e($employ->job_title); ?></td>
                        <td><?php echo e($employ->address); ?></td>
                        <td><?php echo e($employ->date_employed); ?></td>
                        <td><?php echo e($employ->contact_number); ?></td>
                        <td><?php echo e($employ->starting_pay_rate); ?></td>
                        <td><?php echo e($employ->ending_pay_rate); ?></td>
                        <td><?php echo e($employ->separation_reason); ?></td>
                      </tr>
                      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </tbody>
                </table>
                <?php else: ?>
                <h2 class="no_data_found">No data found</h2>
                <?php endif; ?>
              </div>
              
         
         
              <br><br>
              <p class="profile-top-name">Other Attachements<p>

           
                <div class="input-group">
                <?php if(!$requirements->isEmpty()): ?>
                  <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <a href="/files/requirements/<?php echo e($file->file_url); ?>" target="_blank" style="text-decoration:none">
                  <p class="file-p-text"><span class="span-profile-files"><i class="fa fa-file-o" aria-hidden="true"></i></span>
                  <br><span><?php echo e($file->file_url); ?></span></p></a>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
    
                <?php endif; ?>
                </div>
                
              </div>
              <!-- DOCUMENTS -->



          </div>

        </div>



       

  </div>


<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>





<script src="/script/profileform.js"></script>


  
<!--SUBMITTED REQUIRMENTS MODAL-->
<div class="modal fade" id="resume">
  <div class="modal-dialog modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">
      <div class="modal-body">
          <div class="document-wrapper">
          <p class="document"><i class="fa fa-file-text-o" aria-hidden="true"></i></p>
          </div>
          <div class="requirments-instruction"  style="background-color:white">
              <div>
              <form action="<?php echo e(route('submit.resume')); ?>" method="post" enctype="multipart/form-data">
              <?php echo e(csrf_field()); ?>

              <input type='file' id="upfile" name="name" onchange="readURL(this);" style="display:none" />

              <?php if($resume): ?>
              <iframe id="blah" src="/files/resume/<?php echo e($resume->file); ?>" style="width:100%;height:100vh"></iframe>
              <?php else: ?>
              <iframe id="blah" src="http://www.africau.edu/images/default/sample.pdf" style="width:100%;height:100vh"></iframe>
              <?php endif; ?>
              <br><br>

              <button type="submit" class="resume-profile-btn" >Save</button>
              <button type="button" onclick="getFile()" class="resume-profile-btn" >Change file</button>
              <br><br>
              </form>
              </div>
            
          </div>
      </div>

    </div>
  </div>
</div>


</body>
</html>
<?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant//profile/profile.blade.php ENDPATH**/ ?>