<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <link href="/css/hiring.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

<?php echo $__env->make('applicant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

 <!-- <div class="searchbarwrapper">
    <div class="container">
      <input type="text" name="fname" class="searchinput"  placeholder="WHAT"> 
      <input type="text" name="fname" class="searchinput"  placeholder="WHERE"> 
      <button type="button" class="searchbtn">Find Job</button>
      <br>
    </div>
  </div>-->


  <div class="jobdetail-main-wrapper">

        <div class="hiring-thumbnail-wrapper">

        <div class="jobdetailwrapper">
                <p class="jobdetail-title1"><?php echo e($applications->position_applying); ?></p>

                <p class="label-job-title">Job Details</p>

                          <div class="job-details-wrapper">
                            <p class="label-job-title1">Application Status:</p>
                            <p class="job-label2"><?php echo e($applications->employment_status); ?></p>
                            <br>
                            <p class="label-job-title1">Application Details:</p>
                            <p class="job-label2">Date Applied: <?php echo e($applications->date_applied); ?></p>
                            <br>
                            <p class="label-job-title1">Applicant:</p>
                            <p class="job-label2">Name: <?php echo e($applications->lname); ?>, <?php echo e($applications->fname); ?> <?php echo e($applications->mname); ?></p>
                            <p class="job-label2">License: <?php echo e($applications->professional_license); ?></p>
                            <p class="job-label2">Awards: <?php echo e($applications->latin_awards_honors); ?></p>
                            <br>
                            <p class="label-job-title1">Skills:</p>
                            <p class="job-label2">Microsoft Word</p>
                            <p class="job-label2">Microsoft Excel</p>
                            <br>
                            <p class="label-job-title1">Full job Descriptions:</p>
                            <p class="job-summary-label"><?php echo e($applications->date_applied); ?></p>
                            <br>
                            <p class="label-job-title1">Benefits:</p>
                            <p class="job-label2">Health insurance</p>
                            <p class="job-label2">Life insurance</p>
                            <br>
                            <p class="label-job-title1">Schedule:</p>
                            <p class="job-label2">8 hour shift</p>
                            <p class="job-label2">Monday to Friday</p>
                            <br>
                            <p class="label-job-title1">Supplemental Pay:</p>
                            <p class="job-label2">13th month salary</p>
                            <p class="job-label2">Performance bonus</p>
                          </div>
                          
          </div>
        

        </div>

  </div>






<script>
$(document).ready(function(){  
  $(document).on('click', '.get_data', function(){  
           var id = $(this).attr("id");  
           if(id != '')  
           {  
                $.ajax({  
                     url:"/Find/job",  
                     method:"GET",  
                     data:{id:id},  
                     success:function(data){  
                          $('#jddetails').html(data);  
                          $('.default').hide();  
                     }  
                });  
           }            
      });

});
</script>

<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/applicationview.blade.php ENDPATH**/ ?>