
<div class="hr-dashboard-main-content-wrapper">


<!--MAIN HEADER MENU TAB-->
<div class="hrtabbtnwrapper">
    <div class="row">
        <div class="col-sm-8">
            <p class="hr-dashboard-title">For Transferring to E201</p><br>
        </div>
        <div class="col-sm-4">
            <div class="input-group">
                <a href="#"><button id="btnjob" type="button" class="EXPORT-btn">Export</button></a>
                <input type="text" name="seachinput" id="seachinput" class="hr-search-input" placeholder="Search">
            </div>
        </div>
    </div>
</div>

<div class="hrtabbtnwrapper" style="border-bottom:solid 1px white; padding-bottom:15px">
    <a href="/HR/dashboard"><button id="btnhrdashboard" type="button" class="manage-application-tab-btn">All Applications</button></a>
</div>



<!-- LIST OF ALL APPLICATIONS -->
<?php $__currentLoopData = $allapplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <!--CHECK IF IN E201 LIST-->
    <?php $ifonlist = DB::table('tbl_for_e201_transferring')->where('application_id', $applicants->application_id)->where('mrf_id', $applicants->mrf_number)->first(); ?>
    
    <?php if($ifonlist): ?>
    <div class="hrwrapperforapplicationslist">
    <div class="row">
        <div class="col-sm-1">
        <p><i class="fa fa-file" aria-hidden="true"></i></p>
        </div>
        <div class="col-sm-5">
        <p class="position-title"><?php echo e($applicants->lname); ?>, <?php echo e($applicants->fname); ?></p>
        <p class="appplication-label1"><?php echo e($applicants->position_applying); ?></p>
        </div>
        <div class="col-sm-2">
        <p class="view-status-label-row"><strong><i class="fa fa-circle" aria-hidden="true"></i></strong> <?php echo e($applicants->status); ?></p>
        </div>
        <div class="col-sm-2">
        <?php echo $__env->make('hr.applicants.ratings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="col-sm-2">
        <div class="input-group">
            <a href="<?php echo e(route('e201.transfer', ['id' => $applicants->id, 'application_id' => $applicants->application_id])); ?>">
            <button style="width:100%" type="button" class="manageapplicants-btn">Manage</button>
            </a>
        </div>
    </div>
    </div>
    </div>
    <?php else: ?>

    <?php endif; ?>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>






<?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/e201/transfer.blade.php ENDPATH**/ ?>