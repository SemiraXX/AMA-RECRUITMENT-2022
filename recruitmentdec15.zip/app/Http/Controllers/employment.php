<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class employment extends Controller
{
    //
}
