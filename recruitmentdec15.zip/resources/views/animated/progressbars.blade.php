

<div id="myProgress">
    <div class="progress-bar progress-bar-danger" id="progbar15">100%</div>
</div>