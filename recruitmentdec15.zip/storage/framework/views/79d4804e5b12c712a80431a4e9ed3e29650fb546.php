<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

  
  <?php echo $__env->make('applicant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="applicationforwrapper">
    

        <div class="row">

            <div class="col-sm-3">
              <div class="profile-left-wrapper">
                  <p class="appform-title1">Profile</p>
                  <br>
                  <a class="formlink" href="#personalinfo"  ><p class="steps-label1">
                  <span class="steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> 
                  Personal Information</p></a>
                  <br>
                  
                  <?php if($educations): ?>
                  <a class="formlink" href="#education" ><p class="steps-label1">
                  <span class="steps-circle-label">
                  <i class="fa fa-check" aria-hidden="true"></i></span> Educational Background</p></a>
                  <?php else: ?>
                  <a class="formlink" href="#education" ><p class="disabled-steps-label1">
                  <span class="disabled-steps-circle-label">
                  <i class="fa fa-check" aria-hidden="true"></i></span> Educational Background</p></a>
                  <?php endif; ?>
                  <br>

                  
                  <?php if($families): ?>
                  <a class="formlink" href="#family"><p class="steps-label1">
                  <span class="steps-circle-label">
                  <i class="fa fa-check" aria-hidden="true"></i></span> Family Background</p></a>
                  <?php else: ?>
                
                  <p class="disabled-steps-label1"><span class="disabled-steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> Family Background</p>
                  <?php endif; ?>
                  <br>
                  
                  <p class="disabled-steps-label1"><span class="disabled-steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> Employment History</p>
                  <br>
                  <p class="disabled-steps-label1"><span class="disabled-steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> Character Reference</p>
                  <br>
                  <a class="formlink" href="#personalinfo"  ><p class="steps-label1">
                  <span class="steps-circle-label"><i class="fa fa-arrow-up" aria-hidden="true"></i></span> 
                  Back to Top</p></a>
                </div>
            </div>



            <div class="col-sm-9">
                <form action="<?php echo e(route('profile.update')); ?>" method="get" name="profileform" id="profileform">
                <?php echo e(csrf_field()); ?>

                  <div class="profile-save-btn-wrapper" id="personalinfo">
                    <div class="row">
                      <div class="col-sm-10">
                        <div class="input-group">
                        <a class="toplink" href="javascript:void(0)"><p class="profile-label-normal">My Resume /</p></a>
                        <a class="toplink" href="javascript:void(0)"><p class="profile-label-normal">Submitted Requirements /</p></a>
                        <a class="toplink" href="javascript:void(0)"><p class="profile-label-normal">Other Attachements </p></a>
                        </div>
                        
                      </div>
                      <div class="col-sm-2">
                      <button type="button" id="submitprofileform" class="applicantformbtn" >Save</button>
                      </div>
                    </div>
                  </div>

                  <div class="personalinfo">
                  <?php echo $__env->make('applicant.profile.applicationpersonalinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div class="education" id="education">
                  <?php echo $__env->make('applicant.profile.applicationeducation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                  <div class="family" id="family">
                  <?php echo $__env->make('applicant.profile.applicationfamily', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  </div>
                </form>
            </div>

        </div>

  </div>

<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="/script/profileform.js"></script>

</body>
</html>
<?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/profile.blade.php ENDPATH**/ ?>