<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA - HR Dashboard</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/hr.css" rel="stylesheet">
  <link href="/css/hrapplicants.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

  <div class="hrwrapper1">
    

        <div class="row">

                <div class="dashboard-left-side">
                    <?php echo $__env->make('hr.leftmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                </div>

                <div class="dashboard-right-side">
                    
                  <?php echo $__env->make('hr.applicants.forprocessing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   
                </div>
        

        </div><!-- end of row div -->

  </div>
  <div class="messagewrapper" id="evalposted"><div class="alert-box evaluation"><i class="fa fa-warning" aria-hidden="true"></i> Posted </div></div>
  
<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="/script/hr.js"></script>

</body>
</html>
<?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/hr/processing.blade.php ENDPATH**/ ?>