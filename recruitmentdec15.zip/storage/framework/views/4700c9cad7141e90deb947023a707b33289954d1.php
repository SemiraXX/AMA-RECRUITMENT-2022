


<p class="star-rates">
        <?php if(($applicants->latin_awards_honors == "None") || ($applicants->latin_awards_honors == "none")  || ($applicants->latin_awards_honors == "N/A")): ?>
        <?php else: ?>
        <i class="fa fa-star" aria-hidden="true"></i>
        <?php endif; ?>

        <?php if(($applicants->professional_license == "None") || ($applicants->professional_license == "none")  || ($applicants->professional_license == "N/A")): ?>
        <?php else: ?>
        <i class="fa fa-star" aria-hidden="true"></i>
        <?php endif; ?>

        <?php if(($applicants->tesda_cerfitification == "None") || ($applicants->tesda_cerfitification == "none")  || ($applicants->tesda_cerfitification == "N/A")): ?>
        <?php else: ?>
        <i class="fa fa-star" aria-hidden="true"></i>
        <?php endif; ?>

        <?php if(($applicants->driving_license_type == "None") || ($applicants->driving_license_type == "none")  || ($applicants->driving_license_type == "N/A")): ?>
        <?php else: ?>
        <i class="fa fa-star" aria-hidden="true"></i>
        <?php endif; ?>



        <?php if($applicants->been_dismissed == "No"): ?>
        
        <?php else: ?>
        &nbsp; &nbsp; <i class="fa fa-flag" aria-hidden="true" style="color:red"></i>
        <?php endif; ?>


        <?php if($applicants->involved_in_criminal_case == "No"): ?>
        
        <?php else: ?>
        <i class="fa fa-flag" aria-hidden="true" style="color:red"></i>
        <?php endif; ?>
</p><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/applicants/ratings.blade.php ENDPATH**/ ?>