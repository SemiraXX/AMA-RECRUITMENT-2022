


<?php  $province1 = DB::table('tbl_Cities')->where('province_id', '1')->orderBy('name', 'ASC')->get();?>
<?php  $province2 = DB::table('tbl_Cities')->where('province_id', '2')->orderBy('name', 'ASC')->get();?>    
<?php  $province3 = DB::table('tbl_Cities')->where('province_id', '3')->orderBy('name', 'ASC')->get();?>
<?php  $province4 = DB::table('tbl_Cities')->where('province_id', '4')->orderBy('name', 'ASC')->get();?> 
<?php  $province5 = DB::table('tbl_Cities')->where('province_id', '5')->orderBy('name', 'ASC')->get();?>                
<?php  $province6 = DB::table('tbl_Cities')->where('province_id', '6')->orderBy('name', 'ASC')->get();?>
<?php  $province7 = DB::table('tbl_Cities')->where('province_id', '7')->orderBy('name', 'ASC')->get();?>
<?php  $province8 = DB::table('tbl_Cities')->where('province_id', '8')->orderBy('name', 'ASC')->get();?>
<?php  $province9 = DB::table('tbl_Cities')->where('province_id', '9')->orderBy('name', 'ASC')->get();?>
<?php  $province10 = DB::table('tbl_Cities')->where('province_id', '10')->orderBy('name', 'ASC')->get();?>

<?php  $province11 = DB::table('tbl_Cities')->where('province_id', '11')->orderBy('name', 'ASC')->get();?>
<?php  $province12 = DB::table('tbl_Cities')->where('province_id', '12')->orderBy('name', 'ASC')->get();?>    
<?php  $province13 = DB::table('tbl_Cities')->where('province_id', '13')->orderBy('name', 'ASC')->get();?>
<?php  $province14 = DB::table('tbl_Cities')->where('province_id', '14')->orderBy('name', 'ASC')->get();?> 
<?php  $province15 = DB::table('tbl_Cities')->where('province_id', '15')->orderBy('name', 'ASC')->get();?>                
<?php  $province16 = DB::table('tbl_Cities')->where('province_id', '16')->orderBy('name', 'ASC')->get();?>
<?php  $province17 = DB::table('tbl_Cities')->where('province_id', '17')->orderBy('name', 'ASC')->get();?>
<?php  $province18 = DB::table('tbl_Cities')->where('province_id', '18')->orderBy('name', 'ASC')->get();?>
<?php  $province19 = DB::table('tbl_Cities')->where('province_id', '19')->orderBy('name', 'ASC')->get();?>
<?php  $province20 = DB::table('tbl_Cities')->where('province_id', '20')->orderBy('name', 'ASC')->get();?>

<?php  $province21 = DB::table('tbl_Cities')->where('province_id', '21')->orderBy('name', 'ASC')->get();?>
<?php  $province22 = DB::table('tbl_Cities')->where('province_id', '22')->orderBy('name', 'ASC')->get();?>    
<?php  $province23 = DB::table('tbl_Cities')->where('province_id', '23')->orderBy('name', 'ASC')->get();?>
<?php  $province24 = DB::table('tbl_Cities')->where('province_id', '24')->orderBy('name', 'ASC')->get();?> 
<?php  $province25 = DB::table('tbl_Cities')->where('province_id', '25')->orderBy('name', 'ASC')->get();?>                
<?php  $province26 = DB::table('tbl_Cities')->where('province_id', '26')->orderBy('name', 'ASC')->get();?>
<?php  $province27 = DB::table('tbl_Cities')->where('province_id', '27')->orderBy('name', 'ASC')->get();?>
<?php  $province28 = DB::table('tbl_Cities')->where('province_id', '28')->orderBy('name', 'ASC')->get();?>
<?php  $province29 = DB::table('tbl_Cities')->where('province_id', '29')->orderBy('name', 'ASC')->get();?>
<?php  $province30 = DB::table('tbl_Cities')->where('province_id', '30')->orderBy('name', 'ASC')->get();?>

<?php  $province31 = DB::table('tbl_Cities')->where('province_id', '31')->orderBy('name', 'ASC')->get();?>
<?php  $province32 = DB::table('tbl_Cities')->where('province_id', '32')->orderBy('name', 'ASC')->get();?>    
<?php  $province33 = DB::table('tbl_Cities')->where('province_id', '33')->orderBy('name', 'ASC')->get();?>
<?php  $province34 = DB::table('tbl_Cities')->where('province_id', '34')->orderBy('name', 'ASC')->get();?> 
<?php  $province35 = DB::table('tbl_Cities')->where('province_id', '35')->orderBy('name', 'ASC')->get();?>                
<?php  $province36 = DB::table('tbl_Cities')->where('province_id', '36')->orderBy('name', 'ASC')->get();?>
<?php  $province37 = DB::table('tbl_Cities')->where('province_id', '37')->orderBy('name', 'ASC')->get();?>
<?php  $province38 = DB::table('tbl_Cities')->where('province_id', '38')->orderBy('name', 'ASC')->get();?>
<?php  $province39 = DB::table('tbl_Cities')->where('province_id', '39')->orderBy('name', 'ASC')->get();?>
<?php  $province40 = DB::table('tbl_Cities')->where('province_id', '40')->orderBy('name', 'ASC')->get();?>


<?php  $province41 = DB::table('tbl_Cities')->where('province_id', '41')->orderBy('name', 'ASC')->get();?>
<?php  $province42 = DB::table('tbl_Cities')->where('province_id', '42')->orderBy('name', 'ASC')->get();?>    
<?php  $province43 = DB::table('tbl_Cities')->where('province_id', '43')->orderBy('name', 'ASC')->get();?>
<?php  $province44 = DB::table('tbl_Cities')->where('province_id', '44')->orderBy('name', 'ASC')->get();?> 
<?php  $province45 = DB::table('tbl_Cities')->where('province_id', '45')->orderBy('name', 'ASC')->get();?>                
<?php  $province46 = DB::table('tbl_Cities')->where('province_id', '46')->orderBy('name', 'ASC')->get();?>
<?php  $province47 = DB::table('tbl_Cities')->where('province_id', '47')->orderBy('name', 'ASC')->get();?>
<?php  $province48 = DB::table('tbl_Cities')->where('province_id', '48')->orderBy('name', 'ASC')->get();?>
<?php  $province49 = DB::table('tbl_Cities')->where('province_id', '49')->orderBy('name', 'ASC')->get();?>
<?php  $province50 = DB::table('tbl_Cities')->where('province_id', '50')->orderBy('name', 'ASC')->get();?>

<?php  $province51 = DB::table('tbl_Cities')->where('province_id', '51')->orderBy('name', 'ASC')->get();?>
<?php  $province52 = DB::table('tbl_Cities')->where('province_id', '52')->orderBy('name', 'ASC')->get();?>    
<?php  $province53 = DB::table('tbl_Cities')->where('province_id', '53')->orderBy('name', 'ASC')->get();?>
<?php  $province54 = DB::table('tbl_Cities')->where('province_id', '54')->orderBy('name', 'ASC')->get();?> 
<?php  $province55 = DB::table('tbl_Cities')->where('province_id', '55')->orderBy('name', 'ASC')->get();?>                
<?php  $province56 = DB::table('tbl_Cities')->where('province_id', '56')->orderBy('name', 'ASC')->get();?>
<?php  $province57 = DB::table('tbl_Cities')->where('province_id', '57')->orderBy('name', 'ASC')->get();?>
<?php  $province58 = DB::table('tbl_Cities')->where('province_id', '58')->orderBy('name', 'ASC')->get();?>
<?php  $province59 = DB::table('tbl_Cities')->where('province_id', '59')->orderBy('name', 'ASC')->get();?>
<?php  $province60 = DB::table('tbl_Cities')->where('province_id', '60')->orderBy('name', 'ASC')->get();?>

<?php  $province61 = DB::table('tbl_Cities')->where('province_id', '61')->orderBy('name', 'ASC')->get();?>
<?php  $province62 = DB::table('tbl_Cities')->where('province_id', '62')->orderBy('name', 'ASC')->get();?>    
<?php  $province63 = DB::table('tbl_Cities')->where('province_id', '63')->orderBy('name', 'ASC')->get();?>
<?php  $province64 = DB::table('tbl_Cities')->where('province_id', '64')->orderBy('name', 'ASC')->get();?> 
<?php  $province65 = DB::table('tbl_Cities')->where('province_id', '65')->orderBy('name', 'ASC')->get();?>                
<?php  $province66 = DB::table('tbl_Cities')->where('province_id', '66')->orderBy('name', 'ASC')->get();?>
<?php  $province67 = DB::table('tbl_Cities')->where('province_id', '67')->orderBy('name', 'ASC')->get();?>
<?php  $province68 = DB::table('tbl_Cities')->where('province_id', '68')->orderBy('name', 'ASC')->get();?>
<?php  $province69 = DB::table('tbl_Cities')->where('province_id', '69')->orderBy('name', 'ASC')->get();?>
<?php  $province70 = DB::table('tbl_Cities')->where('province_id', '70')->orderBy('name', 'ASC')->get();?>

<?php  $province71 = DB::table('tbl_Cities')->where('province_id', '71')->orderBy('name', 'ASC')->get();?>
<?php  $province72 = DB::table('tbl_Cities')->where('province_id', '72')->orderBy('name', 'ASC')->get();?>    
<?php  $province73 = DB::table('tbl_Cities')->where('province_id', '73')->orderBy('name', 'ASC')->get();?>
<?php  $province74 = DB::table('tbl_Cities')->where('province_id', '74')->orderBy('name', 'ASC')->get();?> 
<?php  $province75 = DB::table('tbl_Cities')->where('province_id', '75')->orderBy('name', 'ASC')->get();?>                
<?php  $province76 = DB::table('tbl_Cities')->where('province_id', '76')->orderBy('name', 'ASC')->get();?>
<?php  $province77 = DB::table('tbl_Cities')->where('province_id', '77')->orderBy('name', 'ASC')->get();?>
<?php  $province78 = DB::table('tbl_Cities')->where('province_id', '78')->orderBy('name', 'ASC')->get();?>
<?php  $province79 = DB::table('tbl_Cities')->where('province_id', '79')->orderBy('name', 'ASC')->get();?>
<?php  $province80 = DB::table('tbl_Cities')->where('province_id', '80')->orderBy('name', 'ASC')->get();?>

<script>
$('.province').on('change', function (e) {

var optionSelected = $("option:selected", this);
var valueSelected = this.value;
if (valueSelected == "id1") {
$('.pro').html('<?php $__currentLoopData = $province1; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');

} else if (valueSelected == "id2") {
$('.pro ').html('<?php $__currentLoopData = $province2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}
else if (valueSelected == "id3") {
$('.pro ').html('<?php $__currentLoopData = $province3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}
else if (valueSelected == "id4") {
$('.pro ').html('<?php $__currentLoopData = $province4; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id5") {
$('.pro ').html('<?php $__currentLoopData = $province5; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id6") {
$('.pro ').html('<?php $__currentLoopData = $province6; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id7") {
$('.pro ').html('<?php $__currentLoopData = $province7; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id8") {
$('.pro ').html('<?php $__currentLoopData = $province8; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id9") {
$('.pro ').html('<?php $__currentLoopData = $province9; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id10") {
$('.pro ').html('<?php $__currentLoopData = $province10; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}


else if (valueSelected == "id11") {
$('.pro ').html('<?php $__currentLoopData = $province11; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id12") {
$('.pro ').html('<?php $__currentLoopData = $province12; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id13") {
$('.pro ').html('<?php $__currentLoopData = $province13; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id14") {
$('.pro ').html('<?php $__currentLoopData = $province14; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id15") {
$('.pro ').html('<?php $__currentLoopData = $province15; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id16") {
$('.pro ').html('<?php $__currentLoopData = $province16; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id17") {
$('.pro ').html('<?php $__currentLoopData = $province17; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id18") {
$('.pro ').html('<?php $__currentLoopData = $province18; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id19") {
$('.pro ').html('<?php $__currentLoopData = $province19; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id20") {
$('.pro ').html('<?php $__currentLoopData = $province20; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}


else if (valueSelected == "id21") {
$('.pro ').html('<?php $__currentLoopData = $province21; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id22") {
$('.pro ').html('<?php $__currentLoopData = $province22; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id23") {
$('.pro ').html('<?php $__currentLoopData = $province23; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id24") {
$('.pro ').html('<?php $__currentLoopData = $province24; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id25") {
$('.pro ').html('<?php $__currentLoopData = $province25; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id26") {
$('.pro ').html('<?php $__currentLoopData = $province26; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id27") {
$('.pro ').html('<?php $__currentLoopData = $province27; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id28") {
$('.pro ').html('<?php $__currentLoopData = $province28; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id29") {
$('.pro ').html('<?php $__currentLoopData = $province29; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id30") {
$('.pro ').html('<?php $__currentLoopData = $province30; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}



else if (valueSelected == "id31") {
$('.pro ').html('<?php $__currentLoopData = $province31; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id32") {
$('.pro ').html('<?php $__currentLoopData = $province32; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id33") {
$('.pro ').html('<?php $__currentLoopData = $province33; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id34") {
$('.pro ').html('<?php $__currentLoopData = $province34; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id35") {
$('.pro ').html('<?php $__currentLoopData = $province35; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id36") {
$('.pro ').html('<?php $__currentLoopData = $province36; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id37") {
$('.pro ').html('<?php $__currentLoopData = $province37; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id38") {
$('.pro ').html('<?php $__currentLoopData = $province38; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id39") {
$('.pro ').html('<?php $__currentLoopData = $province39; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id40") {
$('.pro ').html('<?php $__currentLoopData = $province40; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}



else if (valueSelected == "id41") {
$('.pro ').html('<?php $__currentLoopData = $province41; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id42") {
$('.pro ').html('<?php $__currentLoopData = $province42; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id43") {
$('.pro ').html('<?php $__currentLoopData = $province43; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id44") {
$('.pro ').html('<?php $__currentLoopData = $province44; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id45") {
$('.pro ').html('<?php $__currentLoopData = $province45; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id46") {
$('.pro ').html('<?php $__currentLoopData = $province46; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id47") {
$('.pro ').html('<?php $__currentLoopData = $province47; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id48") {
$('.pro ').html('<?php $__currentLoopData = $province48; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id49") {
$('.pro ').html('<?php $__currentLoopData = $province49; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id50") {
$('.pro ').html('<?php $__currentLoopData = $province50; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}


else if (valueSelected == "id51") {
$('.pro ').html('<?php $__currentLoopData = $province51; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id52") {
$('.pro ').html('<?php $__currentLoopData = $province52; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id53") {
$('.pro ').html('<?php $__currentLoopData = $province53; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id54") {
$('.pro ').html('<?php $__currentLoopData = $province54; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id55") {
$('.pro ').html('<?php $__currentLoopData = $province55; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id56") {
$('.pro ').html('<?php $__currentLoopData = $province56; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id57") {
$('.pro ').html('<?php $__currentLoopData = $province57; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id58") {
$('.pro ').html('<?php $__currentLoopData = $province58; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id59") {
$('.pro ').html('<?php $__currentLoopData = $province59; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id60") {
$('.pro ').html('<?php $__currentLoopData = $province60; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}


else if (valueSelected == "id61") {
$('.pro ').html('<?php $__currentLoopData = $province61; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id62") {
$('.pro ').html('<?php $__currentLoopData = $province62; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id63") {
$('.pro ').html('<?php $__currentLoopData = $province63; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id64") {
$('.pro ').html('<?php $__currentLoopData = $province64; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id65") {
$('.pro ').html('<?php $__currentLoopData = $province65; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id66") {
$('.pro ').html('<?php $__currentLoopData = $province66; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id67") {
$('.pro ').html('<?php $__currentLoopData = $province67; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id68") {
$('.pro ').html('<?php $__currentLoopData = $province68; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id69") {
$('.pro ').html('<?php $__currentLoopData = $province69; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id70") {
$('.pro ').html('<?php $__currentLoopData = $province70; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}



else if (valueSelected == "id71") {
$('.pro ').html('<?php $__currentLoopData = $province71; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id72") {
$('.pro ').html('<?php $__currentLoopData = $province72; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id73") {
$('.pro ').html('<?php $__currentLoopData = $province73; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id74") {
$('.pro ').html('<?php $__currentLoopData = $province74; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id75") {
$('.pro ').html('<?php $__currentLoopData = $province75; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id76") {
$('.pro ').html('<?php $__currentLoopData = $province76; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id77") {
$('.pro ').html('<?php $__currentLoopData = $province77; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id78") {
$('.pro ').html('<?php $__currentLoopData = $province78; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id79") {
$('.pro ').html('<?php $__currentLoopData = $province79; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}else if (valueSelected == "id80") {
$('.pro ').html('<?php $__currentLoopData = $province80; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <option value="<?php echo e($city->name); ?>"><?php echo e($city->name); ?></option> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>');
}


});

</script>
<?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/applicant/location.blade.php ENDPATH**/ ?>