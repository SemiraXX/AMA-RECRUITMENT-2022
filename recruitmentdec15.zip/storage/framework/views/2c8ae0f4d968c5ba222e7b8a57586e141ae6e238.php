
<div class="hr-dashboard-main-content-wrapper">

    <!--MAIN HEADER MENU TAB-->
    <?php echo $__env->make('hr.resume.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="divresume">
    <table class="table">
    <thead>
        <tr>
        <th scope="col">ID</th>
        <th scope="col">Date Submitted</th>
        <th scope="col">Application ID</th>
        <th scope="col">File</th>
        <th scope="col">File Url</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $uploadedresume; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resume): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
        <td scope="row"><?php echo e($resume->id); ?></th>
        <td><?php echo e($resume->date_submitted); ?></td>
        <td><?php echo e($resume->applicationID); ?></td>
        <td><?php echo e($resume->file_name); ?></td>
        <td><i class="fa fa-file-text-o" aria-hidden="true"></i> <a class="viewresumelink" href="/files/resume/<?php echo e($resume->file_url); ?>" target="_blank"><?php echo e($resume->file_url); ?></a></td>
        </tr>
        <tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        
    </tbody>
    </table>
    </div>


</div><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/resume/list.blade.php ENDPATH**/ ?>