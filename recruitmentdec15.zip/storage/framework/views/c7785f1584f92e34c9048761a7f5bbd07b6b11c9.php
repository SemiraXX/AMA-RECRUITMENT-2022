        
   <form action="<?php echo e(route('form.submit')); ?>" method="post">
        <?php echo e(csrf_field()); ?>


        <div class="profile-save-btn-wrapper">
              <div class="row">
                <div class="col-sm-10">
                <p class="label-job-title"><?php echo e($specificjd->JDDescription); ?></P>
                </div>
                <div class="col-sm-2">
                <?php  $checkconsent = DB::table('tbl_consentform')->where('userid', '=', session('applicantsession'))->first(); ?>
                <?php if($checkconsent): ?>
                <button type="submit" class="applicantformbtn">Submit</button>
                <?php else: ?>
                <button type="button" class="applicantformbtn get_data" id="submitapplicationform">Continue</button>
                <?php endif; ?>
                
                </div>
              </div>
        </div>

        <div class="applicationforwrapper3">
          <div class="form-application-detail">
            <label class="form-label">Job Summary</label>
            <p class="job-summary-label"><?php echo e($specificjd->Summary); ?></p>
          </div>
        </div>
  
        <div class="applicationforwrapper2">
            <!--PERSONAL INFO 1ST ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-3">
                  <label class="form-label">First Name</label>
                  <input type="text" name="fname" class="appform-input"  value="<?php echo e($applicants->fname); ?>" readonly style="cursor:not-allowed"> 
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Last Name</label>
                  <input type="text" name="lname" class="appform-input"  value="<?php echo e($applicants->lname); ?>" readonly style="cursor:not-allowed"> 
                </div>
                <div class="col-sm-2">
                  <label class="form-label">Middle</label>
                  <input type="text" name="mname" class="appform-input"  value="<?php echo e($applicants->mname); ?>" readonly style="cursor:not-allowed"> 
                </div>
                <div class="col-sm-1">
                  <label class="form-label">Suffix</label>
                  <input type="text" name="suffix" class="appform-input"  value="<?php echo e($applicants->suffix); ?>" readonly style="cursor:not-allowed"> 
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Nickname</label>
                  <input type="text" name="nickname" class="appform-input"  value="<?php echo e($applicants->nickname); ?>" readonly style="cursor:not-allowed"> 
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Gender</label>
                  <select name="gender" class="appform-input" style="cursor:not-allowed;pointer-events:none">
                      <option value="--Select--">Select</option>
                      <?php if($applicants->gender == "Male"): ?>
                      <option value="Male" selected>Male</option>
                      <?php else: ?>
                      <option value="Male">Male</option>
                      <?php endif; ?>
                      <?php if($applicants->gender == "Female"): ?>
                      <option value="Female" selected>Female</option>
                      <?php else: ?>
                      <option value="Female">Female</option>
                      <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Email</label>
                  <input type="email" name="email" class="appform-input"  value="<?php echo e($applicants->email); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Contact Number</label>
                  <input type="text" name="contact_number" class="appform-input"  value="<?php echo e($applicants->contact_number); ?>" readonly style="cursor:not-allowed">  
                </div>
            </div>
            <!--END OF PERSONAL INFO 1ST ROW-->


            <br>

            <!--PERSONAL INFO 2nd ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-12">
                  <label class="form-label">Complete Address</label>
                  <input type="text" name="complete_address" class="appform-input"  value="<?php echo e($applicants->complete_address); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Province</label>
                  <?php $stores = DB::table('tbl_Province')->orderBy('Province', 'ASC')->get();?>
                  <select name="province" class="province appform-input locationoption" style="cursor:not-allowed;pointer-events:none"> 
                  <option value="id15" selected><?php echo e($applicants->province); ?></option>
                  <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="id<?php echo e($store->id); ?>"><?php echo e($store->Province); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>
                </div>
                <div class="col-sm-4">
                  <label class="form-label">City/Town</label>
                  <?php  $cities = DB::table('tbl_Cities')->orderBy('name', 'ASC')->get();?>
                  <select class="appform-input pro locationoption" name="city"  id="cities" readonly style="cursor:not-allowed;pointer-events:none"> 
                  <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <option value="<?php echo e($city->name); ?> City"><?php echo e($city->name); ?></option>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </select>     
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Brgy.</label>
                  <input type="text" name="brgy" class="appform-input"  value="<?php echo e($applicants->brgy); ?>" style="cursor:not-allowed;pointer-events:none">  
                </div>
            </div>
            <!--END OF PERSONAL INFO 2nd ROW-->

         
            <br>


            <!--PERSONAL INFO 3rd ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-3">
                  <label class="form-label">Birth Date</label>
                  <input type="date" name="birthdate" class="appform-input"  value="<?php echo e($applicants->birthdate); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Birth Place</label>
                  <input type="text" name="birthplace" class="appform-input"  value="<?php echo e($applicants->birthplace); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Citizenship</label>
                  <input type="text" name="citizenship" class="appform-input"  value="<?php echo e($applicants->citizenship); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Religion</label>
                  <input type="text" name="religion" class="appform-input"  value="<?php echo e($applicants->religion); ?>" readonly style="cursor:not-allowed">  
                </div>

                <div class="col-sm-2">
                  <label class="form-label">Civil Status</label>  
                  <select name="civilstatus" class="appform-input" style="cursor:not-allowed;pointer-events:none">
                      <option value="--Select--">Select</option>
                      <?php if($applicants->civilstatus == "Married"): ?>
                      <option value="Married" selected>Married</option>
                      <?php else: ?>
                      <option value="Married">Married</option>
                      <?php endif; ?>
                      <?php if($applicants->civilstatus == "Single"): ?>
                      <option value="Single" selected>Single</option>
                      <?php else: ?>
                      <option value="Single">Single</option>
                      <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Mother Name</label>
                  <input type="text" name="mother_name" class="appform-input"  value="<?php echo e($applicants->mother_name); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Father Name</label>
                  <input type="text" name="father_name" class="appform-input"  value="<?php echo e($applicants->father_name); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Spouse</label>
                  <input type="text" name="spouse" class="appform-input"  value="<?php echo e($applicants->spouse); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-1">
                  <label class="form-label">Siblings</label>
                  <input type="number" name="no_of_siblings" class="appform-input"  value="<?php echo e($applicants->no_of_siblings); ?>" readonly style="cursor:not-allowed">  
                </div>
            </div>
            <!--END OF PERSONAL INFO 3rd ROW-->


            <br>


            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-6">
                  <label class="form-label">Drivers License</label> 
                  <select name="drivers_license" class="appform-input" style="cursor:not-allowed;pointer-events:none">
                      <option value="--Select--">Select</option>
                      <?php if($applicants->drivers_license == "Professional"): ?>
                      <option value="Professional" selected>Professional</option>
                      <?php else: ?>
                      <option value="Professional">Professional</option>
                      <?php endif; ?>
                      <?php if($applicants->drivers_license == "Non-Professional"): ?>
                      <option value="Non-Professional" selected>Non-Professional</option>
                      <?php else: ?>
                      <option value="Non-Professional">Non-Professional</option>
                      <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Restrictions</label>
                  <input type="text" name="restriction" class="appform-input"  value="<?php echo e($applicants->restriction); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Other License</label>
                  <input type="text" name="other_license" class="appform-input"  placeholder="type here..">  
                </div>
            </div>
            <!--ENF OF PERSONAL INFO 4TH ROW-->

            <br>

            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-3">
                  <label class="form-label">SSS</label>
                  <input type="text" name="sss" class="appform-input"  value="<?php echo e($applicants->sss); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">TIN</label>
                  <input type="text" name="tin" class="appform-input"  value="<?php echo e($applicants->tin); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Philhealth</label>
                  <input type="text" name="philhealth" class="appform-input"  value="<?php echo e($applicants->philhealth); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Pagibig</label>
                  <input type="text" name="pagibig" class="appform-input"  value="<?php echo e($applicants->pagibig); ?>" readonly style="cursor:not-allowed">  
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->
            
            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-4">
                  <label class="form-label">Licensed Professional?</label><br>
                  <input type="checkbox" id="licenseno" >
                  <label class="form-label">No</label> &nbsp;&nbsp;
                  <input type="checkbox" id="licenseyes">
                  <label class="form-label">Yes, (Please Indicate)</label><br><br>
                  <input type="text" name="professional_license" id="professional_license" class="appform-input" required>

                </div>
                <div class="col-sm-4">
                  <label class="form-label">Currently Employed?</label><br>
                  <input type="checkbox" id="emplyedno" >
                  <label class="form-label">No</label> &nbsp;&nbsp;
                  <input type="checkbox" id="emplyedyes">
                  <label class="form-label">Yes</label>
                  <input type="hidden" name="employed" id="employed" class="appform-input" required>
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Previously Employed?</label><br>
                  <input type="checkbox" id="preemplyedno" >
                  <label class="form-label">No</label> &nbsp;&nbsp;
                  <input type="checkbox" id="preemplyedyes">
                  <label class="form-label">Yes</label>
                  <input type="hidden" name="previouly_employed" id="previouly_employed" class="appform-input" required>
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->

            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-12">
                  <label class="form-label" style="line-height:18px !important">RELATED BY 6TH DEGREE OF CONSANGUINITY OR AFFINITY UP TO ANY EMPLOYEE OF AMA?</label>
                  <br><input type="checkbox" id="relatedtoamano" >
                  <label class="form-label">No</label> &nbsp;&nbsp;
                  <input type="checkbox" id="relatedtoamayes">
                  <label class="form-label">Yes, (Please Indicate)</label>
                  <input type="text" name="related_to_ama_employee" id="related_to_ama_employee" class="appform-input" placeholder="type here...">  
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->


            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-12">
                  <label class="form-label" style="line-height:18px !important">HAVE YOU EVER BEEN DISMISSED BY YOUR FORMER EMPLOYERS? FOR ANY ADMINISTRATIVE OR JUST CAUSE?</label>
                  <br><input type="checkbox" id="dismissedno" >
                  <label class="form-label">No</label> &nbsp;&nbsp;
                  <input type="checkbox" id="dismissedyes">
                  <label class="form-label">Yes, (Please Indicate)</label>
                  <input type="text" name="been_dismissed" id="been_dismissed" class="appform-input" placeholder="type here...">  
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->



            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-12">
                  <label class="form-label" style="line-height:18px !important">HAVE YOU EVER BEEN INVOLVED IN ANY ADMINISTRATIVE, CIVIL OR CRIMINAL CASE?</label><br>
                  <input type="checkbox" id="crimincalno" >
                  <label class="form-label">No</label> &nbsp;&nbsp;
                  <input type="checkbox" id="crimincalyes">
                  <label class="form-label">Yes, (Please Indicate)</label>
                  <input type="text" name="involved_in_criminal_case" id="involved_in_criminal_case" class="appform-input" placeholder="type here...">  
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->


             <!--PERSONAL INFO 4TH ROW-->
             <div class="row applicantrowwrapper">
                <div class="col-sm-6">
                  <label class="form-label">Postion Applying</label>
                  <input type="text" name="position_applying" class="appform-input"  value="<?php echo e($specificjd->JDDescription); ?>" readonly>  
                </div>
                <div class="col-sm-6">
                  <label class="form-label">Desired Salary*</label>
                  <input type="text" name="desired_salary" class="appform-input"  placeholder="type here..." required>  
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->


            <!--PERSONAL INFO 4TH ROW-->
            <div class="row applicantrowwrapper">
                <div class="col-sm-4">
                  <label class="form-label">Latin Awards</label>
                  <input type="text" name="latin_awards_honors" class="appform-input"  placeholder="type here..." required>  
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Tesda Certification</label>
                  <input type="text" name="tesda_cerfitification" class="appform-input"  placeholder="type here..." required>  
                </div>
                <div class="col-sm-4">
                  <label class="form-label">WHERE DID YOU HEAR ABOUT US?</label>
                  <input type="text" name="when_hear_about_us" class="appform-input"  placeholder="type here..." required>  
                </div>
            </div>
            <br>
            <!--END OF PERSONAL INFO 4TH ROW-->

            <?php echo $__env->make('applicant.location', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <br>
            </div>
  </form>

  <script src="/script/application.js"></script><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/profileforapplication.blade.php ENDPATH**/ ?>