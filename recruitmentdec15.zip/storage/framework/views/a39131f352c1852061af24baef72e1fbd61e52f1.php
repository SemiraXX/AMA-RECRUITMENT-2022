



<div class="row">
<?php $__currentLoopData = $allvacancies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="col-sm-12">
        <div class="jobthumbnail">
        <img src="/assets/ama-br-logo.png" class="job-logo">
        <p class="job-label1"><?php echo e($job->JDDescription); ?></p>
        <p class="job-label2"><?php echo e($job->Summary); ?></p>
        <button type="button" class="headermenubtn">View</button>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/joblist.blade.php ENDPATH**/ ?>