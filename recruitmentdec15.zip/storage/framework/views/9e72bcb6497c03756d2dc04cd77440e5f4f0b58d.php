<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <link href="/css/applicationview.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <link rel="stylesheet" href="path/to/font-awesome/css/font-awesome.min.css">
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

<?php echo $__env->make('applicant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <div class="view-main-wrapper">

        <div class="row">

            <div class="col-sm-5">
              <div class="transparentjobwrapper">
                <?php echo $__env->make('applicant.applications.progress', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
              </div>
            </div>



            <!--APPLICATION DETAILS-->
            <div class="col-sm-7">
          
              <div class="whitejobwrapper">
                <p class="view-application-job-title"><?php echo e($applications->position_applying); ?></p>
                <p class="label-job-title">Application details</p>
                <div class="job-details-wrapper">
                <p class="label-job-title1">Application Status:</p>
                <p class="job-label2"><?php echo e($applications->employment_status); ?></p>
                <br>
                <p class="label-job-title1">Application Details:</p>
                <p class="job-label2">Date Applied: <?php echo e($applications->date_applied); ?></p>
                <br>
                <p class="label-job-title1">Applicant:</p>
                <p class="job-label2">Name: <?php echo e($applications->lname); ?>, <?php echo e($applications->fname); ?> <?php echo e($applications->mname); ?></p>
                <p class="job-label2">License: <?php echo e($applications->professional_license); ?></p>
                <p class="job-label2">Awards: <?php echo e($applications->latin_awards_honors); ?></p>
                <br>
                <p class="label-job-title1">Skills:</p>
                <p class="job-label2">Microsoft Word</p>
                <p class="job-label2">Microsoft Excel</p>
                <br>
                <p class="label-job-title1">Full job Descriptions:</p>
                <p class="job-summary-label"><?php echo e($applications->date_applied); ?></p>
                <br>
                <p class="label-job-title1">Benefits:</p>
                <p class="job-label2">Health insurance</p>
                <p class="job-label2">Life insurance</p>
                <br>
                <p class="label-job-title1">Schedule:</p>
                <p class="job-label2">8 hour shift</p>
                <p class="job-label2">Monday to Friday</p>
                <br>
                <p class="label-job-title1">Supplemental Pay:</p>
                <p class="job-label2">13th month salary</p>
                <p class="job-label2">Performance bonus</p>
              </div>
            </div>


        </div>  

  </div>
        



  

<?php echo $__env->make('applicant.applications.modals', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<script src="/script/view.js"></script>


</body>
</html><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/applications/applicationview.blade.php ENDPATH**/ ?>