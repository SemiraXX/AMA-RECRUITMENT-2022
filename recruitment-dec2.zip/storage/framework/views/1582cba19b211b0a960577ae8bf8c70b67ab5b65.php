

<div class="applicationforwrapper3">
        <p class="appform-title2">3. Family Background</p>
</div>


<div class="applicationforwrapper2">

    <?php if(!$families->isEmpty()): ?>
        <?php $__currentLoopData = $families; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $family): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="applicantrowwrapper">
                <div class="row">
                  <div class="col-sm-5">
                    <label class="form-label">Name</label>
                    <input type="text" name="name[]" id="name[]" class="appform-input" value="<?php echo e($family->name); ?>"  placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-4">
                    <label class="form-label">Relationship</label>
                    <input type="text" name="relationship[]" id="relationship[]" class="appform-input"  value="<?php echo e($family->relationship); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-3">
                    <label class="form-label">Birthdate</label>
                    <input type="text" onfocus="(this.type='date')" name="familybirthday[]" id="familybirthday[]" class="appform-input"  value="<?php echo e($family->birthday); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-3">
                    <label class="form-label">Occupation</label>
                    <input type="text" name="occupation[]" id="occupation[]" class="appform-input"  value="<?php echo e($family->occupation); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-3">
                    <label class="form-label">Contact No.</label>
                    <input type="text" name="famcontact_number[]" id="famcontact_number[]" class="appform-input"  value="<?php echo e($family->contact_number); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-6">
                    <label class="form-label">Address</label>
                    <div class="input-group">
                      <input type="text" name="famaddress[]" id="famaddress[]" class="appform-input"  value="<?php echo e($family->address); ?>" required> 
                    </div>
                  </div>
                </div>
                <a href="<?php echo e(route('family.delete', ['id' => $family->id])); ?>">
                  <button type="button" class="delete-append-div"><i class="fa fa-trash" aria-hidden="true"></i> remove</button>
                  <input type="hidden"  name="id"   value="<?php echo e($family->id); ?>"> 
                </a>
            </div><br>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    
    <?php endif; ?>

       <section id="familywrapperappend"></section>
       <button id="appendfamily">Add more</button>

</div><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/profile/applicationfamily.blade.php ENDPATH**/ ?>