    
    
<!--APPLICATION FORM-->

<div class="row">

    <div class="col-sm-3">
          <p class="appform-title1">Profile</p>
          <br>

          <a class="formlink" href="javascript:void(0)" onclick="personalinfo()"><p class="steps-label1">
            <i class="fa fa-arrow-right sltd1"></i>
            <span class="steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> 
            Personal Information</p></a>
          <br>

          <a class="formlink" href="javascript:void(0)" onclick="education()"><p class="disabled-steps-label1">
            <i class="fa fa-arrow-right sltd2"></i>
            <span class="disabled-steps-circle-label">
            <i class="fa fa-check" aria-hidden="true"></i></span> Educational Background</p></a>
          <br>

          <p class="disabled-steps-label1"><span class="disabled-steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> Family Background</p>
          <br>
          <p class="disabled-steps-label1"><span class="disabled-steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> Employment History</p>
          <br>
          <p class="disabled-steps-label1"><span class="disabled-steps-circle-label"><i class="fa fa-check" aria-hidden="true"></i></span> Character Reference</p>
    </div>

    <div class="col-sm-9">
        
        <div class="personalinfo">
            <?php echo $__env->make('applicant.applicationpersonalinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="education">
            <?php echo $__env->make('applicant.applicationeducation', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
       
    </div>


</div>
    
    
<script>
    
//hide tempo the other panel
$(".education").hide();
$(".sltd2").hide();

function personalinfo(){
    $(".personalinfo").animate( { "opacity": "show", top:"100"} , 800 );
    $(".education").hide();
    $(".sltd1").show();
    $(".sltd2").hide();
}

function education(){
    $(".education").animate( { "opacity": "show", top:"100"} , 800 );
    $(".personalinfo").hide();
    $(".sltd1").hide();
    $(".sltd2").show();
}


</script><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/applicationform.blade.php ENDPATH**/ ?>