

<p class="tab-title-text">Employment</P>
    <br><br>
    <div class="row">
        <div class="col-sm-12">
            <p class="e201-form-label">Branch:</p>
            <input type="text" name="Branchcode" class="not-allowed-e201-input" value="AMACC - Panay"  > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-12">
            <p class="e201-form-label">Department:</p>
            <input type="text" name="DeptCode" class="not-allowed-e201-input" value="RESEARCH AND DEVELOPMENT DEPARTMENT"  > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-12">
            <p class="e201-form-label">Job Description:</p>
            <input type="text" name="" class="not-allowed-e201-input" value="<?php echo e($applicants->position_applying); ?>"  > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-12">
            <p class="e201-form-label">Title:</p>
            <input type="text" name="" class="e201-input" value="<?php echo e($applicants->mname); ?>"  > 
        </div>
    </div>  
    <br><br>
    <div class="row">
        <div class="col-sm-3">
            <p class="e201-form-label">Employee Status:</p>
            <input type="text" name="" class="not-allowed-e201-input" value="Fixed Term"  > 
        </div>
        <div class="col-sm-3">
            <p class="e201-form-label">Start Date:</p>
            <input type="date" name="start2" class="e201-input" > 
        </div>

        <div class="col-sm-3">
            <p class="e201-form-label">Time Keeping:</p>
            <select name="educational_level[]" class="e201-input" >
                <option selected>Select</option>
                <?php $__currentLoopData = $timekeeping; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $time): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($time->TKDescription); ?>"><?php echo e($time->TKDescription); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
                    
        </div>

        <div class="col-sm-3">
            <p class="e201-form-label">Tax Shield Percentage:</p>
            <input type="text" name="" class="e201-input" value="0" > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-6">
            <p class="e201-form-label">Required Hours:</p>
            <input type="text" name="" class="e201-input" value="0"  > 
        </div>
        <div class="col-sm-6">
            <p class="e201-form-label">Required Hours Label:</p>
            <input type="text" name="" class="e201-input"value="---"  > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-4">
            <p class="e201-form-label">Basic Pay Scheme Type:</p>
            <select name="educational_level[]" class="e201-input" >
                <option value="Matrix">Matrix</option>
                <option value="Custom">Custom</option>
            </select>
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Rank:</p>
            <select name="educational_level[]" class="e201-input" >
                <option selected>Select</option>
                <?php $__currentLoopData = $ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($rank->KeyCode); ?>"><?php echo e($rank->KeyDesc); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Rank Level:</p>
            <input type="number" name="" class="e201-input" value="1"  > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-4">
            <p class="e201-form-label">Matrix Group:</p>
            <select name="educational_level[]" class="e201-input" >
                <option selected>Select</option>
                <?php $__currentLoopData = $matrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mtrx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($mtrx->KeyCode); ?>"><?php echo e($mtrx->KeyDesc); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Sub Group:</p>
            <select name="educational_level[]" class="e201-input" >
            <option value="none">Select</option>
            <?php $__currentLoopData = $submatrix; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $submtrx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($submtrx->KeyCode); ?>"><?php echo e($submtrx->KeyDesc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Basic Rate Value:</p>
            <input type="number" name="" class="e201-input" value="1"  > 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-4">
            <p class="e201-form-label">Basic Rate Label:</p>
            <select name="educational_level[]" class="e201-input" >
            <option value="none">Select</option>
            <?php $__currentLoopData = $PayType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $brl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($brl->KeyCode); ?>"><?php echo e($brl->KeyDesc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Pay Currency:</p>
            <select name="educational_level[]" class="e201-input" >
            <option value="none">Select</option>
            <?php $__currentLoopData = $Currency; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $crncy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($crncy->KeyCode); ?>"><?php echo e($crncy->KeyDesc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="col-sm-4">
            <p class="e201-form-label">Payout Mode:</p>
            <select name="educational_level[]" class="e201-input" >
            <option value="none">Select</option>
            <?php $__currentLoopData = $PayoutMode; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pytmode): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($pytmode->KeyCode); ?>"><?php echo e($pytmode->KeyDesc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select> 
        </div>
    </div>
    <br><br>
    <div class="row">
        <div class="col-sm-6">
            <p class="e201-form-label">Computation Type:</p>
            <select name="educational_level[]" class="e201-input" >
            <option value="none">Select</option>
            <?php $__currentLoopData = $CompType; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cmptyp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cmptyp->KeyCode); ?>"><?php echo e($cmptyp->KeyDesc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select> 
        </div>
        <div class="col-sm-6">
            <p class="e201-form-label">CompBen Group:</p>
            <select name="educational_level[]" class="e201-input" >
            <option value="none">Select</option>
            <?php $__currentLoopData = $CompBenGrp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cbg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($cbg->KeyCode); ?>"><?php echo e($cbg->KeyDesc); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select> 
        </div>
    </div>
    <br><br>
  <?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/hr/e201/employmentinfo.blade.php ENDPATH**/ ?>