


<!--LEFT MENU NAV-->
<img src="/assets/ama-br-logo.png" class="bar-logo">

                  <div class="buttonswrapper">

                    <a href="/HR/job/posting">
                    <button type="button" class="side-menu-btn">
                      <i class="fa fa-list" aria-hidden="true"></i> &nbsp; Job Posting
                    </button>
                    </a>

                    <a href="/HR/dashboard">
                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-users" aria-hidden="true"></i> &nbsp; Applicants
                    </button></a>

                    <a href="/HR/Transfer/e201">
                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-exchange" aria-hidden="true"></i> &nbsp; For E201
                    </button></a>

                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-file-text" aria-hidden="true"></i> &nbsp; Requests
                    </button>

                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-bell" aria-hidden="true"></i> &nbsp; Notifications
                    </button>

                    <br><br><br><br><br>

                    <button type="button" class="side-menu-btn">
                    <i class="fa fa-user" aria-hidden="true"></i> &nbsp; Account
                    </button>
                    
                  </div><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/leftmenu.blade.php ENDPATH**/ ?>