

<!--MANAGE APPLICATION PROGRESS-->
<p class="progress-step-title">Application Progress Logs</p>
                <br>
                <ul class="events">



                <!--THIS IS THE LATEST STATUS-->
                <?php if($lateststatus): ?>

                        <?php if($lateststatus->status == "Awaiting"): ?>

                        <?php elseif($lateststatus->status == "For-Onboarding"): ?>

                            <li>
                                <time datetime="1">*</time>
                                <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                <br><br>
                                <a href="https://forms.gle/LETsyXkPmpHvruPL7 on">Onboarding notes</a>
                                </span>
                                <br><br>
                            </li>

                        <?php elseif($lateststatus->status == "For-Pre-Employment-Requirements"): ?>


                            <!--TO CHECK IF HAS REQUIREMENTS-->
                            <?php if($requirements->isEmpty()): ?>
                              <li>
                                <time datetime="1">*</time>
                                <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                <br>
                                <button type="submit" class="take-exam-btn uploadrequirments">Upload Requirments</button>
                                </span>
                                <br><br>
                              </li>
                              <?php else: ?>
                              <li>
                                <time datetime="1">*</time>
                                <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                <br>
                                <button type="submit" class="take-exam-btn viewattachement">Your Attachements</button>
                                <button type="submit" class="take-exam-btn uploadrequirments">Upload Requirments</button>
                                </span>
                                <br><br>
                              </li>
                              <?php endif; ?>
                              <!--TO CHECK IF HAS REQUIREMENTS-->


                        <?php elseif($lateststatus->status == "For-Criteria-Evaluation"): ?>

                              <?php if(!$requirements->isEmpty()): ?>
                              <li>
                                <time datetime="1">*</time>
                                <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                <br>
                                <button type="submit" class="take-exam-btn viewattachement">Your Attachements</button>
                                </span>
                                <br><br>
                              </li>
                              <?php else: ?>
                              <li>
                                <time datetime="1">*</time>
                                <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                <br>
                                <button type="submit" class="take-exam-btn uploadcredentials">Upload Requirments</button>
                                </span>
                                <br><br>
                              </li>
                              <?php endif; ?>
                              

                        <?php elseif(($lateststatus->status == "For-Exam") || ($lateststatus->status == "For-Exam-and-Essay")): ?>

                                <!--TO CHECK IF HAS EXAM-->
                                <?php if($examresults->isEmpty()): ?>
                                  <li>
                                    <time datetime="1">*</time>
                                    <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                    Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                    <br>
                                    <button type="submit" class="take-exam-btn takeexambtn">Take Exam</button>
                                    </span>
                                    <br><br>
                                  </li>
                                  <?php else: ?>
                                  <li>
                                    <time datetime="1">*</time>
                                    <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                    Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                    <br>
                                    <p class="completed-label">Exam Completed</p>
                                    </span>
                                    <br><br>
                                  </li>
                                  <?php endif; ?>
                                <!--TO CHECK IF HAS EXAM-->
                                  
                        <?php else: ?>

                              <li>
                                <time datetime="1">*</time>
                                <span><strong class="completed-label"><?php echo e($lateststatus->status); ?></strong>
                                Message: <?php echo e($lateststatus->message); ?> <br> (<?php echo e($lateststatus->data_modified); ?>)
                                </span>
                                <br><br>
                              </li>

                        <?php endif; ?>




                <?php else: ?>

                <?php endif; ?>





                <!--PREVIOUS PROGRESS-->
                <?php $__currentLoopData = $applicationstatuses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                    <?php if(($status->status == "For-Exam") || ($status->status == "For-Exam-and-Essay")): ?>

                          <!--TO CHECK IF HAS EXAM-->
                          <?php if($examresults->isEmpty()): ?>
                          <li class="past-progress">
                            <time datetime="1">*</time>
                            <span><strong clas="steps-title"><?php echo e($status->status); ?></strong>
                            Message: <?php echo e($status->message); ?> <br> (<?php echo e($status->data_modified); ?>)
                            <br>
                            <button type="submit" class="take-exam-btn takeexambtn">Take Exam</button>
                            </span>
                            <br><br>
                          </li>
                          <?php else: ?>
                          <li class="past-progress">
                            <time datetime="1">*</time>
                            <span><strong clas="steps-title"><?php echo e($status->status); ?></strong>
                            Message: <?php echo e($status->message); ?> <br> (<?php echo e($status->data_modified); ?>)
                            <br>
                            <p class="completed-label">Exam Completed</p>
                            </span>
                            <br><br>
                          </li>
                          <?php endif; ?>
                           <!--TO CHECK IF HAS EXAM-->

                    <?php elseif($status->status == "For-Pre-Employment-Requirements"): ?>


                          <!--TO CHECK IF HAS REQUIREMENTS-->
                          <?php if($requirements->isEmpty()): ?>
                          <li class="past-progress">
                            <time datetime="1">*</time>
                            <span><strong clas="steps-title"><?php echo e($status->status); ?></strong>
                            Message: <?php echo e($status->message); ?> <br> (<?php echo e($status->data_modified); ?>)
                            <br>
                            <button type="submit" class="take-exam-btn uploadrequirments">Upload Requirments</button>
                            </span>
                            <br><br>
                          </li>
                          <?php else: ?>
                          <li class="past-progress">
                            <time datetime="1">*</time>
                            <span><strong clas="steps-title"><?php echo e($status->status); ?></strong>
                            Message: <?php echo e($status->message); ?> <br> (<?php echo e($status->data_modified); ?>)
                            <br>
                            <button type="submit" class="take-exam-btn viewattachement">View Attachements</button>
                            </span>
                            <br><br>
                          </li>
                          <?php endif; ?>
                          <!--TO CHECK IF HAS REQUIREMENTS-->





                    <?php elseif($status->status == "For-Criteria-Evaluation"): ?>


                          <li class="past-progress">
                            <time datetime="1">*</time>
                            <span><strong clas="steps-title"><?php echo e($status->status); ?></strong>
                            Message: <?php echo e($status->message); ?> <br> (<?php echo e($status->data_modified); ?>)
                            <br>
                            <button type="submit" class="take-exam-btn uploadrequirments">Upload Requirments</button>
                            </span>
                            <br><br>
                          </li>



                    <?php else: ?>

                    <li class="past-progress">
                      <time datetime="1">*</time>
                      <span><strong clas="steps-title"><?php echo e($status->status); ?></strong>
                      Message: <?php echo e($status->message); ?> <br> (<?php echo e($status->data_modified); ?>)</span>
                      <br><br>
                    </li>

                    <?php endif; ?>

                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



                  <!--default progress after submission-->
                  <li class="past-progress">
                      <time datetime="1">*</time> 
                      <span><strong clas="steps-title">Waiting for the employer</strong></span>
                      <br><br>
                  </li>

                  <li class="past-progress">
                      <time datetime="1">*</time> 
                      <span><strong clas="steps-title">Applied</strong><?php echo e($applications->date_applied); ?></span>
                      <br><br>
                  </li>
                      
                  </ul><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/applications/progress.blade.php ENDPATH**/ ?>