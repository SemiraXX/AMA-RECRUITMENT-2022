

<!--MODALS-->



<!--CREDENTIAL REQUIRMENTS MODAL-->
<div class="modal fade" id="uploadcredrequirments">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <div class="modal-body">
          <div class="document-wrapper">
          <p class="document"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></p>
          </div>
          <div class="requirments-instruction"  style="background-color:white">
          <p class="requirments-note-title">Upload all requirements</p>
    
            <form action="<?php echo e(route('document.submit')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

              <table class="table">
                <thead>
                  <tr>
                    <th>Requirements</th>
                    <th></th>
                    <th>File</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $credentials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if(($docu->FlUploadCode == "TOR") ||
                  ($docu->FlUploadCode == "DIPLOMA") ||
                  ($docu->FlUploadCode == "PRCLICENSE") ||
                  ($docu->FlUploadCode == "AWARDS") ||
                  ($docu->FlUploadCode == "OTHERS")): ?>

                  <tr>
                    <th><?php echo e($docu->FlUploadDesc); ?> 
                      <input type="hidden" name="reqname[]" value="<?php echo e($docu->FlUploadDesc); ?>">
                      <input type="hidden" name="reqcode[]" value="<?php echo e($docu->FlUploadCode); ?>">
                    </th>
                    <td><input type="file"  name="name[]" style="width:300px"></td>
                    <td>none</td>
                  </tr>
                  <?php else: ?>

                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              
              <p class="requirments-note-text">*Upload your complete credetials in pdf format. You can merge mutilple document in one pdf file.</p>
              <input type="hidden" name="usernamereq" value="<?php echo e($applications->lname); ?>">
              <input type="hidden" name="useridreq" value="<?php echo e($applications->userid); ?>">
              <input type="hidden" name="appidreq" value="<?php echo e($applications->application_id); ?>">
              <button type="submit" class="upload-btn">Upload <i class="fa fa-upload" aria-hidden="true"></i></button>
              <br>
            </form>
          </div>
      </div>

    </div>
  </div>
</div>







<!--REQUIRMENTS MODAL-->
  <div class="modal fade" id="uploadrequirments">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <div class="modal-body">
          <div class="document-wrapper">
          <p class="document"><i class="fa fa-file-pdf-o" aria-hidden="true"></i></p>
          </div>
          <div class="requirments-instruction"  style="background-color:white">
          <p class="requirments-note-title">Upload all requirements</p>
            <form action="<?php echo e(route('document.submit')); ?>" method="post" enctype="multipart/form-data">
            <?php echo e(csrf_field()); ?>

              <table class="table">
                <thead>
                  <tr>
                    <th>Requirements</th>
                    <th></th>
                    <th>File</th>
                  </tr>
                </thead>
                <tbody>
                <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php  $checkrequirements = DB::table('tbl_requirements')->where('file_code', $docu->FlUploadCode)->first(); ?>
                   <?php if($checkrequirements): ?>
                      <tr>
                        <th><?php echo e($docu->FlUploadDesc); ?> 
                          <input type="hidden" name="reqname[]" value="<?php echo e($docu->FlUploadDesc); ?>">
                          <input type="hidden" name="reqcode[]" value="<?php echo e($docu->FlUploadCode); ?>">
                        </th>
                        <td>submitted</td>
                        <td><?php echo e($checkrequirements->file_name); ?></td>
                      </tr>
                    <?php else: ?>
                    <tr>
                        <th><?php echo e($docu->FlUploadDesc); ?> 
                          <input type="hidden" name="reqname[]" value="<?php echo e($docu->FlUploadDesc); ?>">
                          <input type="hidden" name="reqcode[]" value="<?php echo e($docu->FlUploadCode); ?>">
                        </th>
                        <td><input type="file"  name="name[]" style="width:300px"></td>
                        <td>none</td>
                      </tr>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
              </table>
              <input type="hidden" name="usernamereq" value="<?php echo e($applications->lname); ?>">
              <input type="hidden" name="useridreq" value="<?php echo e($applications->userid); ?>">
              <input type="hidden" name="appidreq" value="<?php echo e($applications->application_id); ?>">
              <button type="submit" class="upload-btn">Upload <i class="fa fa-upload" aria-hidden="true"></i></button>
              <br>
            </form>
          </div>
      </div>

    </div>
  </div>
</div>





  <!--SUBMITTED REQUIRMENTS MODAL-->
  <div class="modal fade" id="attachementrequirments">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <div class="modal-body">
          <div class="document-wrapper">
          <p class="document"><i class="fa fa-file-text-o" aria-hidden="true"></i></p>
          </div>
          <div class="requirments-instruction"  style="background-color:white">
          <p class="requirments-note-title">Document Files</p>
          <br>
            <div class="row">
              <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $file): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="col-sm-2">
              <a href="/files/requirements/<?php echo e($file->file_url); ?>" target="_blank" style="text-decoration:none">
              <h1 class="document-icon"><i class="fa fa-file-text-o" aria-hidden="true"></i></h1>
              <p class="document-name"><?php echo e($file->file_url); ?></p>
              </a>
              </div>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <br><br>
            <button type="submit" class="upload-req-btn addmorereq">Upload Document</button>
            <br><br>
            <a class="docu-back-to closemodal1" href="#back">close</a>
          </div>
      </div>

    </div>
  </div>
</div>



<!--UPLOAD MORE REQUIRMENTS MODAL-->
<div class="modal fade" id="addrequirments">
  <div class="modal-dialog modal-dialog-centered modal-md">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <div class="modal-body">
        <form action="<?php echo e(route('document.submit')); ?>" method="post" enctype="multipart/form-data">
        <?php echo e(csrf_field()); ?>

          <div class="document-wrapper">
            <p class="document"><i class="fa fa-file-text-o" aria-hidden="true"></i></p>
            </div>
            <div class="requirments-instruction"  style="background-color:white">
            <p class="requirments-note-title">Upload additional requirement</p>
            <br>
            <select name="reqcode[]" class="appform-input" required>
              <?php $__currentLoopData = $documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php $ifposted = DB::table('tbl_requirements')
              ->where('application_id', $applications->application_id)
              ->where('file_code', $docu->FlUploadCode)->first(); ?>

              <?php if($ifposted): ?>
              <option value="<?php echo e($docu->FlUploadCode); ?>" disabled class="disabled"><span><i class="fa fa-check-circle-o" aria-hidden="true"></i></span><?php echo e($docu->FlUploadDesc); ?></option>
              <?php else: ?>
              <option value="<?php echo e($docu->FlUploadCode); ?>" class="notdisabled"><?php echo e($docu->FlUploadDesc); ?></option>
              <?php endif; ?>
             

              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <input type="hidden" name="reqname[]" value="default">
            <input type="file" class="appform-input"  name="name[]" required>
            <input type="hidden" name="usernamereq" value="<?php echo e($applications->lname); ?>">
            <input type="hidden" name="useridreq" value="<?php echo e($applications->userid); ?>">
            <input type="hidden" name="appidreq" value="<?php echo e($applications->application_id); ?>">
            <br><br>
            <button type="submit" class="upload-req-btn">Upload</button>
            <br><br>
            <a class="docu-back-to backtomodal" href="#back"><i class="fa fa-chevron-left" aria-hidden="true"></i> Back</a>
          </div>
        </form>
      </div>

    </div>
  </div>
</div>






  <!--INSTRUCTION MODAL-->
  <div class="modal fade" id="beforeexammodalnote">
  <div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <div class="modal-body">
          <div class="exclamation-instruction-wrapper">
          <p class="exclamation"><i class="fa fa-exclamation" aria-hidden="true"></i></p>
          </div>
          <div class="exam-instruction"  style="background-color:white">
          <p class="exam-note-title">Please read the instructions carefully</p>
          <p class="note-label">1. Exam contains 63 mulitple questions and 1 essay portion.</p>
          <p class="note-label">2. You only have 30 minutes to submit your answer</p>
          <p class="note-label">3. Don't close browser to avoid reset</p>
          <button type="submit" class="note-exam-btn viewexambtn">Proceed to Exam</button>
          <button type="submit" class="note-exam-btn closemodal">Cancel</button>
          <br>
          </div>
      </div>

    </div>
  </div>
</div>






<!--EXAM SHEET MODAL-->
<div class="modal fade" id="exammodal">
<div class="modal-dialog modal-dialog-centered modal-lg">
    <div class="modal-content"  style="background-color:transparent;border:none;">

      <div class="modal-body">

      <div class="exammessagewrapper" id="examwraning"><div class="alert-box exam"><i class="fa fa-warning" aria-hidden="true"></i> 10 seconds left </div></div>
        <!--TIMER DESIGN-->
        <div class="timer-wrapper">
          <div id="safeTimer">
            <h2 class="timer-label">Exam Timer</h2>
            <p class="timer-count-label" id="safeTimerDisplay">00:30</p>
          </div>
        </div>

        <div class="input-group tab-wrapper">
            <a href="#"><button id="btntabprofile" type="button" onclick="exam()" class="modal-info-tab-btn">Exam</button></a>
            <a href="#"><button id="btnother" type="button" onclick="essay()" class="modal-info-tab-btn">Essay</button></a>
        </div>
        <div class="container"  style="background-color:white">
        <br>
        <form action="<?php echo e(route('answer.submit')); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <?php if($lateststatus): ?>

            <?php if(($lateststatus->status == "For-Exam") || ($lateststatus->status == "For-Exam-and-Essay")): ?>

                <div class="exam-content-wrapper">
                <p class="label-job-title">Examination</p>
                  <?php $examination = DB::table('ExamDetails')->where('SetCode', $lateststatus->exam)->get(); ?>
                  <?php $__currentLoopData = $examination; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $myexam): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="exam-wrapper">
                  <p class="exam-question"><?php echo e($myexam->Question); ?></p>
                  <div class="input-group answergroup answerwrapper">
                    <div class="checkbox">
                    <label class="exam-choices"><strong>A.</strong> <input type="radio" name="<?php echo e($myexam->QuestionNo); ?>[]" class="checkbox-input thisradio" value="<?php echo e($myexam->ChoiceA); ?>"> <?php echo e(trim($myexam->ChoiceA,"_01")); ?></label>
                    </div>
                    <div class="exam-choices">
                    <label><strong>B.</strong> <input type="radio" name="<?php echo e($myexam->QuestionNo); ?>[]"  class="checkbox-input thisradio" value="<?php echo e($myexam->ChoiceB); ?>"> <?php echo e(trim($myexam->ChoiceB,"_01")); ?></label>
                    </div>
                    <div class="exam-choices">
                    <label><strong>C.</strong> <input type="radio" name="<?php echo e($myexam->QuestionNo); ?>[]"  class="checkbox-input thisradio" value="<?php echo e($myexam->ChoiceC); ?>"> <?php echo e(trim($myexam->ChoiceC,"_01")); ?></label>
                    </div>
                    <div class="exam-choices">
                    <label><strong>D.</strong> <input type="radio" name="<?php echo e($myexam->QuestionNo); ?>[]"  class="checkbox-input thisradio" value="<?php echo e($myexam->ChoiceD); ?>"> <?php echo e(trim($myexam->ChoiceD,"_01")); ?></label>
                    </div>
                  <input type="hidden" name="answer[]" id="answerget" value="none"> 
                  <input type="hidden" name="question[]" value="<?php echo e($myexam->QuestionNo); ?>">  
                  <input type="hidden" name="code[]" value="<?php echo e($myexam->SetCode); ?>">
                  </div>
                  </div>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>

            <?php else: ?>
                    
            <?php endif; ?>
        <?php else: ?>

        <?php endif; ?>

        
        <input type="hidden" name="application_id" value="<?php echo e($applications->application_id); ?>"> 
        

        <div class="exam-content-wrapper">
          <button type="submit" id="examsubmitthis" class="submit-exam-btn">Submit</button>
          <br><br>
        </div>
        

        </form>
        

        <br><br>
        </div>
      </div>

    </div>
  </div>
</div>
<?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/applicant/applications/modals.blade.php ENDPATH**/ ?>