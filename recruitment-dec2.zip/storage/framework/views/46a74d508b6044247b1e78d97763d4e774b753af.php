
<div class="hr-dashboard-main-content-wrapper">

<!--MAIN HEADER MENU TAB-->
<?php echo $__env->make('hr.applicants.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<!-- LIST OF ALL APPLICATIONS -->

<?php $__currentLoopData = $allapplications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $applicants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="hrwrapperforapplicationslist">
<div class="row">
    <div class="col-sm-1">
    <p><i class="fa fa-file" aria-hidden="true"></i></p>
    </div>
    <div class="col-sm-5">
    <p class="position-title"><?php echo e($applicants->lname); ?>, <?php echo e($applicants->fname); ?></p>
    <p class="appplication-label1"><?php echo e($applicants->position_applying); ?></p>
    </div>
    <div class="col-sm-2">
      <p class="view-status-label-row"><strong><i class="fa fa-spinner" aria-hidden="true"></i></strong> <?php echo e($applicants->status); ?></p>
    </div>
    <div class="col-sm-2">
      <?php echo $__env->make('hr.applicants.ratings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col-sm-2">
      <div class="input-group">
          <button style="width:100%" type="button" class="manageapplicants-btn evaluate_data" id="<?php echo e($applicants->id); ?>" onclick="this.style.backgroundColor='#ACACAC'">Review File</button>
      </div>
  </div>
</div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



</div>





<!-- The Modal -->
<div class="modal fade" id="applicantdetailsforeval">
<div class="modal-dialog modal-dialog-centered modal-xl">
  <div class="modal-content"  style="background-color:transparent;border:none;">

    <!-- Modal body -->
    <div class="modal-body">

      <div class="input-group tab-wrapper">
          <a href="#"><button id="btntabfile" type="button" onclick="tabfile()" class="hr-applicant-info-tab-btn info-tab-btn-active">File</button></a>
          <a href="#"><button id="btntabprofile" type="button" onclick="tabprofile()" class="hr-applicant-info-tab-btn">Profile</button></a>
          <a href="#"><button id="btntprocessrequirements" type="button" onclick="requirements()" class="hr-applicant-info-tab-btn">Documents</button></a>
      </div>
      <div class="container"  style="background-color:white">
      <br>
      
      <form action="<?php echo e(route('update.status')); ?>" method="post">
          <?php echo e(csrf_field()); ?>

          <div id="applicant_details"></div>
      </form>

      <button type="button" class="btn btn-danger" data-bs-dismiss="modal">Close</button>
      <br> <br>
      </div>
    </div>

  </div>
</div>
</div>


<?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/applicants/forevaluation.blade.php ENDPATH**/ ?>