

<p class="tab-title-text">Uploaded Documents</P>
<br>
    <!--requirements-->
    <p class="e201-form-label">Employment History</p>
    <table class="table">
    <tr>
        <th style="width:10%">file_code</th>
        <th style="width:20%">requirement_name</th>
        <th>file_url</th>
        <th>date_submitted</th>
        <th>View</th>
    </tr>
    <?php $__currentLoopData = $requirements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $requirement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($requirement->file_code); ?></td>
        <td><?php echo e($requirement->requirement_name); ?></td>
        <td><?php echo e($requirement->file_url); ?></td>
        <td><?php echo e($requirement->date_submitted); ?></td>
        <td><a href="/files/requirements/<?php echo e($requirement->file_url); ?>" target="_blank">View</a></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/e201/documents.blade.php ENDPATH**/ ?>