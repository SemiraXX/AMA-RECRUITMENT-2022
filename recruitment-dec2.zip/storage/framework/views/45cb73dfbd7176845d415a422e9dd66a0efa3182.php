


<div class="hr-dashboard-main-content-wrapper">

    <div class="hrtabbtnwrapper">
    <div class="row">
        <div class="col-sm-8">
            <p class="hr-dashboard-title"><?php echo e($applicants->application_id); ?></p><br>
        </div>
        <div class="col-sm-4">
        
        </div>
    </div>
    </div>

    <div class="hrtabbtnwrapper" style="border-bottom:solid 1px white; padding-bottom:15px">
        <button id="personalinfo" onclick="personalinfo()" type="button" class="manage-application-tab-btn">Personal Info</button>
        <button id="employmentinfo" onclick="employmentinfo()" type="button" class="manage-application-tab-btn">Employment</button>
        <button id="otherdetails" onclick="otherdetails()" type="button" class="manage-application-tab-btn">Other Details</button>
        <button id="documents" onclick="documents()" type="button" class="manage-application-tab-btn">Documents</button>
    </div>

<div class="form-wrapper-for-e201">
<form action="<?php echo e(route('e201.proceed')); ?>" method="post">
    <?php echo e(csrf_field()); ?>

    <button type="submit" class="trasfer-btn">Transfer to E201</button>
    <div class="personalinfo">
        <?php echo $__env->make('hr.e201.personalinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="employmentinfo">
        <?php echo $__env->make('hr.e201.employmentinfo', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="otherdetails">
        <?php echo $__env->make('hr.e201.otherdetails', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <div class="documents">
        <?php echo $__env->make('hr.e201.documents', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>

    <br><br>
    <input type="hidden" name="id" value="<?php echo e($applicants->id); ?>">
    </form>
</div>


</div>






<?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/hr/e201/transferform.blade.php ENDPATH**/ ?>