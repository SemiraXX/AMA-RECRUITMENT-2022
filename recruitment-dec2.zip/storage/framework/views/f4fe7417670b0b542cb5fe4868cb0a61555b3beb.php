

<div class="applicationforwrapper3">
        <p class="appform-title2">2. Educational Background</p>
</div>


<div class="applicationforwrapper2">
        
        <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="applicantrowwrapper">
          <div class="row">
                  <div class="col-sm-4">
                    <label class="form-label">Education Level</label>
                    <select name="educational_level[]" class="appform-input" required>
                      <option value="<?php echo e($education->educational_level); ?>" selected><?php echo e($education->educational_level); ?></option>
                      <option value="High School">High School</option>
                      <option value="College Graduate">Bachelor/College Graduate</option>
                      <option value="Masters Graduate">Masters Graduate</option>
                      <option value="Masters Graduate">PhD Graduate</option>
                    </select>
                    
                  </div>
                  
                  <div class="col-sm-4">
                    <label class="form-label">Name of Institution</label>
                    <input type="text" name="name_of_institution[]" id="name_of_institution[]" class="appform-input"  value="<?php echo e($education->name_of_institution); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-4">
                    <label class="form-label">Degree Earned</label>
                    <input type="text" name="degree[]" id="degree[]" class="appform-input"  value="<?php echo e($education->degree); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-8">
                    <label class="form-label">Address</label>
                    <input type="text" name="address[]" id="address[]" class="appform-input"  value="<?php echo e($education->address); ?>" placeholder="type here..." required> 
                  </div>
                  <div class="col-sm-4">
                    <label class="form-label">Year Graduated</label>
                    <div class="input-group">
                      <input type="text"  onfocus="(this.type='date')" name="date_attended[]" id="date_attended[]" class="appform-input"  value="<?php echo e($education->date_attended); ?>" required> 
                    </div>
                  </div>
          </div>
            
                <a href="<?php echo e(route('educattainment.delete', ['id' => $education->id])); ?>">
                  <button type="button" class="delete-append-div"><i class="fa fa-trash" aria-hidden="true"></i> remove</button>
                  <input type="hidden"  name="id"   value="<?php echo e($education->id); ?>"> 
                </a>
        </div><br>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        

       <section id="educationalwrapperappend"></section>
       <button type="button" id="btn2">Add more</button>

</div><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/profile/applicationeducation.blade.php ENDPATH**/ ?>