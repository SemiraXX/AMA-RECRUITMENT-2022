<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA - Departmen Head Dashboard</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/hr.css" rel="stylesheet">
  <link href="/css/hrapplicants.css" rel="stylesheet">
  <link href="/css/resigned.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

  <div class="hrwrapper1">
    

        <div class="row">

                <div class="dashboard-left-side">
                  <img src="/assets/ama-br-logo.png" class="bar-logo">

                  <?php echo $__env->make('depthead.leftmenu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                  
                </div>


                <div class="dashboard-right-side">
                  <?php echo $__env->make('depthead.resigned.list', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                   
                </div>
        

        </div><!-- end of row div -->

  </div>

<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<script src="/script/resigned.js"></script>

</body>
</html>
<?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/depthead/dashboard.blade.php ENDPATH**/ ?>