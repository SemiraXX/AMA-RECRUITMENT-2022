

<p class="tab-title-text">Other Details</P>

    <br><br>
    <p class="e201-form-label">Cotact Information</p>
    
    <table class="table">
    <tr>
        <th style="width:5%">ID</th>
        <th style="width:20%">Detail</th>
        <th>Content</th>
    </tr>
    <tr>
        <td>1</td>
        <th>Contact No.</td>
        <td><?php echo e($applicants->contact_no); ?></td>
    </tr>
    <tr>
        <td>2</td>
        <th>Present Address</td>
        <td><?php echo e($applicants->present_address); ?></td>
    </tr>
    <tr>
        <td>3</td>
        <th>Province</td>
        <td><?php echo e($applicants->province); ?></td>
    </tr>
    <tr>
        <td>4</td>
        <th>City</td>
        <td><?php echo e($applicants->province); ?></td>
    </tr>
    </table>

    <br>
    
    <p class="e201-form-label">Government ID's</p>
    <table class="table">
    <tr>
        <th style="width:5%">ID</th>
        <th style="width:20%">Detail</th>
        <th>Content</th>
    </tr>
    <tr>
        <td>1</td>
        <th>sss</td>
        <td><?php echo e($applicants->sss); ?></td>
    </tr>
    <tr>
        <td>2</td>
        <th>tin</td>
        <td><?php echo e($applicants->tin); ?></td>
    </tr>
    <tr>
        <td>3</td>
        <th>philhealth</td>
        <td><?php echo e($applicants->philhealth); ?></td>
    </tr>
    <tr>
        <td>4</td>
        <th>pagibig</td>
        <td><?php echo e($applicants->pagibig); ?></td>
    </tr>
    </table>


    <br>
    <!--EDUCATION BG-->
    <p class="e201-form-label">Education Background</p>
    <table class="table">
    <tr>
        <th style="width:5%">ID</th>
        <th style="width:20%">Level</th>
        <th>Institution</th>
        <th>Address</th>
        <th>Degree</th>
        <th style="width:10%">Date Attended</th>
    </tr>
    <?php $__currentLoopData = $educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>1</td>
        <th><?php echo e($education->educational_level); ?></td>
        <td><?php echo e($education->name_of_institution); ?></td>
        <td><?php echo e($education->address); ?></td>
        <td><?php echo e($education->degree); ?></td>
        <td><?php echo e($education->date_attended); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <br>
    <!--EMPLOYMENT BG-->
    <p class="e201-form-label">Employment History</p>
    <table class="table">
    <tr>
        <th style="width:5%">ID</th>
        <th style="width:20%">Employer</th>
        <th>Positio</th>
        <th>Address</th>
        <th>Date Employed</th>
        <th>Separation Reason</th>
    </tr>
    <?php $__currentLoopData = $employment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $emph): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td>1</td>
        <th><?php echo e($emph->employer); ?></td>
        <td><?php echo e($emph->job_title); ?></td>
        <td><?php echo e($emph->address); ?></td>
        <td><?php echo e($emph->date_employed); ?></td>
        <td><?php echo e($emph->separation_reason); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/hr/e201/otherdetails.blade.php ENDPATH**/ ?>