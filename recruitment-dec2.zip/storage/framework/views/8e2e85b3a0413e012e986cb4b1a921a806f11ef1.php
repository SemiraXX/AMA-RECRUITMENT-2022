

<?php if(count($errors) > 0): ?>
<div class="messagewrapper">
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="alert-box error"><i class="fa fa-warning"></i> <?php echo e($error); ?></div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<script>$(window).on("load", function () {$( "div.error" ).fadeIn(200 ).delay(1200).fadeOut( 4000 );});</script>
<?php endif; ?>


<?php if(Session::get('notes')): ?>
<div class="messagewrapper"><div class="alert-box check"><i class="fa fa-check" aria-hidden="true"></i> <?php echo e(Session::get('notes')); ?></div></div>
<script>$(window).on("load", function () {$( "div.check" ).fadeIn(200 ).delay(1200).fadeOut( 4000 );});</script>
<?php endif; ?>


<?php if(Session::get('checknotes')): ?>
<div class="messagewrapper"><div class="alert-box error"><i class="fa fa-warning" aria-hidden="true"></i> <?php echo e(Session::get('checknotes')); ?></div></div>
<script>$(window).on("load", function () {$( "div.error" ).fadeIn(200 ).delay(1200).fadeOut( 4000 );});</script>
<?php endif; ?>


<div class="messagewrapper" id="process"><div class="alert-box check process"><i class="fa fa-warning" aria-hidden="true"></i> Processing...</div></div>


<script>
$("#process").hide();
$("#evalposted").hide();
</script><?php /**PATH C:\xampp22\htdocs\recruitment\resources\views/animated/popups.blade.php ENDPATH**/ ?>