<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">
<br><br>
  <div class="applicationforwrapper">

      <div class="applicationforwrapper2">
          <br><br>
          <p class="appform-title1">Application Form</p>
          <br>
          <a href="/applicant/logout"><button type="button" class="logoutapplicantformbtn">Logout</button></a>
          <br><br>
        <form action="<?php echo e(route('form.update')); ?>" method="get">
        <?php echo e(csrf_field()); ?>

          <div class="row">
                <div class="col-sm-3">
                  <label class="form-label">First Name</label>
                  <input type="text" name="fname" class="appform-input"  value="<?php echo e($applicants->fname); ?>" required> 
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Last Name</label>
                  <input type="text" name="lname" class="appform-input"  value="<?php echo e($applicants->lname); ?>" required> 
                </div>
                <div class="col-sm-2">
                  <label class="form-label">Middle</label>
                  <input type="text" name="mname" class="appform-input"  value="<?php echo e($applicants->mname); ?>" required> 
                </div>
                <div class="col-sm-1">
                  <label class="form-label">Suffix</label>
                  <input type="text" name="suffix" class="appform-input"  value="<?php echo e($applicants->suffix); ?>" required> 
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Nickname</label>
                  <input type="text" name="nickname" class="appform-input"  value="<?php echo e($applicants->nickname); ?>" required> 
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Gender</label>
                  <select name="gender" class="appform-input" required>
                      <option value="--Select--">Select</option>
                      <?php if($applicants->gender == "Male"): ?>
                      <option value="Male" selected>Male</option>
                      <?php else: ?>
                      <option value="Male">Male</option>
                      <?php endif; ?>
                      <?php if($applicants->gender == "Female"): ?>
                      <option value="Female" selected>Female</option>
                      <?php else: ?>
                      <option value="Female">Female</option>
                      <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Email</label>
                  <input type="email" name="email" class="appform-input"  value="<?php echo e($applicants->email); ?>" readonly style="cursor:not-allowed">  
                </div>
                <div class="col-sm-4">
                  <label class="form-label">Contact Number</label>
                  <input type="text" name="contact_number" class="appform-input"  value="<?php echo e($applicants->contact_number); ?>" required>  
                </div>

          </div>

          <hr><br>

          <div class="row">
                <div class="col-sm-12">
                  <label class="form-label">Complete Address</label>
                  <input type="text" name="complete_address" class="appform-input"  value="<?php echo e($applicants->complete_address); ?>" required>  
                </div>

                
                <div class="col-sm-4">
                  <label class="form-label">Brgy.</label>
                  <input type="text" name="brgy" class="appform-input"  value="<?php echo e($applicants->brgy); ?>" required>  
                </div>
          </div>

          <hr><br>


          <div class="row">
                <div class="col-sm-3">
                  <label class="form-label">Birth Date</label>
                  <input type="date" name="birthdate" class="appform-input"  value="<?php echo e($applicants->birthdate); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Birth Place</label>
                  <input type="text" name="birthplace" class="appform-input"  value="<?php echo e($applicants->birthplace); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Citizenship</label>
                  <input type="text" name="citizenship" class="appform-input"  value="<?php echo e($applicants->citizenship); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Religion</label>
                  <input type="text" name="religion" class="appform-input"  value="<?php echo e($applicants->religion); ?>" required>  
                </div>

                <div class="col-sm-2">
                  <label class="form-label">Civil Status</label>  
                  <select name="civilstatus" class="appform-input" required>
                      <option value="--Select--">Select</option>
                      <?php if($applicants->civilstatus == "Married"): ?>
                      <option value="Married" selected>Married</option>
                      <?php else: ?>
                      <option value="Married">Married</option>
                      <?php endif; ?>
                      <?php if($applicants->civilstatus == "Single"): ?>
                      <option value="Single" selected>Single</option>
                      <?php else: ?>
                      <option value="Single">Single</option>
                      <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Mother Name</label>
                  <input type="text" name="mother_name" class="appform-input"  value="<?php echo e($applicants->mother_name); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Father Name</label>
                  <input type="text" name="father_name" class="appform-input"  value="<?php echo e($applicants->father_name); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Spouse</label>
                  <input type="text" name="spouse" class="appform-input"  value="<?php echo e($applicants->spouse); ?>" required>  
                </div>
                <div class="col-sm-1">
                  <label class="form-label">Siblings</label>
                  <input type="number" name="no_of_siblings" class="appform-input"  value="<?php echo e($applicants->no_of_siblings); ?>" required>  
                </div>
          </div>


          <hr><br>


          <div class="row">
                <div class="col-sm-6">
                  <label class="form-label">Drivers License</label> 
                  <select name="drivers_license" class="appform-input" required>
                      <option value="--Select--">Select</option>
                      <?php if($applicants->drivers_license == "Professional"): ?>
                      <option value="Professional" selected>Professional</option>
                      <?php else: ?>
                      <option value="Professional">Professional</option>
                      <?php endif; ?>
                      <?php if($applicants->drivers_license == "Non-Professional"): ?>
                      <option value="Non-Professional" selected>Non-Professional</option>
                      <?php else: ?>
                      <option value="Non-Professional">Non-Professional</option>
                      <?php endif; ?>
                  </select>
                </div>
                <div class="col-sm-6">
                  <label class="form-label">Restrictions</label>
                  <input type="text" name="restriction" class="appform-input"  value="<?php echo e($applicants->restriction); ?>" required>  
                </div>
          </div>

          <hr><br>

          <div class="row">
                <div class="col-sm-3">
                  <label class="form-label">SSS</label>
                  <input type="text" name="sss" class="appform-input"  value="<?php echo e($applicants->sss); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">TIN</label>
                  <input type="text" name="tin" class="appform-input"  value="<?php echo e($applicants->tin); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Philhealth</label>
                  <input type="text" name="philhealth" class="appform-input"  value="<?php echo e($applicants->philhealth); ?>" required>  
                </div>
                <div class="col-sm-3">
                  <label class="form-label">Pagibig</label>
                  <input type="text" name="pagibig" class="appform-input"  value="<?php echo e($applicants->pagibig); ?>" required>  
                </div>
          </div>
          <br><br>
          <button type="submit" class="applicantformbtn">Save</button>
          <br><br>
        </form>
          
      </div>

  </div>

<?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/applicantdashboard.blade.php ENDPATH**/ ?>