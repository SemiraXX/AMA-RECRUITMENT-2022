<!DOCTYPE html>
<html lang="en">
<head>
<title>AMA</title>
  <link href="/css/applicant.css" rel="stylesheet">
  <link href="/css/style.css" rel="stylesheet">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <?php echo $__env->make('design.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>
<body style="background-color:#EFEFEF">

  <?php echo $__env->make('applicant.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <div class="applicationswrapper">

        <div class="applicationswrapper2">

            <p class="appform-title1">Applications</p><br>

            <?php $__currentLoopData = $applications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="row submittedapplicationswrapper">
                <div class="col-sm-1">
                <img src="/assets/ama-br-logo.png" class="application-logo">
                </div>
                <div class="col-sm-9">
                    <p class="position-title"><?php echo e($application->position_applying); ?> <span class="status-label"><?php echo e($application->employment_status); ?></span></p>
                    <p class="appplication-label1">AMA Lucena Campus</p>
                    <p class="appplication-label1">Lucena Quezon</p>
                    <p class="appplication-label1"><?php echo e($application->date_applied); ?></p>
                </div>
                <div class="col-sm-2">
                <form action="<?php echo e(route('application.view')); ?>" method="get">
                    <button type="submit" class="updateapplicationbtn">Manage</button>
                    <input type="hidden"  name="id"  value="<?php echo e($application->id); ?>"> 
                </form>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <div class="row submittedapplicationswrapper">
                <div class="col-sm-1">
                <img src="/assets/ABE-college-icon.png" class="application-logo">
                </div>
                <div class="col-sm-9">
                    <p class="position-title">Web Designer & Developer <span class="status-label">For Interview</p></p>
                    <p class="appplication-label1">AMA Lucena Campus</p>
                    <p class="appplication-label1">Lucena Quezon</p>
                    <p class="appplication-label1">Applied on June 21, 2022</p>
                </div>
                <div class="col-sm-2">
                    <button type="button" class="updateapplicationbtn">Manage</button>
                </div>
            </div>

        </div>
  </div>

  <?php echo $__env->make('animated.popups', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <script src="/script/application.js"></script>
</body>
</html><?php /**PATH C:\xampp8\htdocs\recruitment\resources\views/applicant/applications.blade.php ENDPATH**/ ?>